/**
 * Title:        ����������ֹ�˾���оֵ������Ľӿڳ���
 * Description:
 * Copyright:    Copyright (c) 2002
 * Company:      ������Զ��Ϣ�������޹�˾
 * @author��     ����
 * @version��    1.0
 * StartDate:   2002/07/11
 * EndDate:
 */
package cast_client_server;

import javax.swing.UIManager;
import java.awt.*;

public class main_run {
    boolean packFrame = false;

    /**Construct the application*/
    public main_run() {
        main_frame frame = new main_frame();
        //Validate frames that have preset sizes
        //Pack frames that have useful preferred size info, e.g. from their layout
        if (packFrame) {
            frame.pack();
        }
        else {
            frame.validate();
        }
        //Center the window
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        Dimension frameSize = frame.getSize();
        if (frameSize.height > screenSize.height) {
            frameSize.height = screenSize.height;
        }
        if (frameSize.width > screenSize.width) {
            frameSize.width = screenSize.width;
        }
        frame.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
        frame.setVisible(true);
    }
    /**Main method*/
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        }
        catch(Exception e) {
            e.printStackTrace();
        }
        new main_run();
    }
}