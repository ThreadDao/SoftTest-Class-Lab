/**
 * Title:        ����������ֹ�˾���оֵ������Ľӿڳ���
 * Description:
 * Copyright:    Copyright (c) 2002
 * Company:      ������Զ��Ϣ�������޹�˾
 * @author��     ����
 * @version��    1.0
 * StartDate:    2002/07/11
 * EndDate:      2002/07/12
 */
package cast_client_server;

import java.text.*;
import java.util.*;
import java.util.Date;
import java.util.StringTokenizer;
public class CommFunc
{

    public CommFunc()
    {
    }
     //���ڲ���
    static public  String DateAdd(String type,int step,String S)
    {
    //��������'2001-01-01'�����ĸ�ʽ��������������
    if (S.length()==10)
        S=S+" 00:00:00";
    String re="NULL";
    SimpleDateFormat formatter = new SimpleDateFormat ("yyyy-MM-dd HH:mm:ss");
    ParsePosition pos = new ParsePosition(0);
    java.util.Date d=formatter.parse(S,pos);
    Calendar calendar = new GregorianCalendar();
    calendar.setTime(d);
    if (type=="YY")
        calendar.add(calendar.YEAR,step);
    if (type=="MM")
        calendar.add(calendar.MONTH,step);
    if (type=="DD")
        calendar.add(calendar.DAY_OF_MONTH,step);
    if (type=="HH")
        calendar.add(calendar.HOUR,step);
    if (type=="MI")
        calendar.add(calendar.MINUTE,step);
    if(type=="SS")
        calendar.add(calendar.SECOND,step);
    d=calendar.getTime();
    re=formatter.format(d);
    return re.trim();
    }

    // �ַ����ض���ʽת����
    static public  Date getdate(String S)
    {
    if (S.length()==10)
        S=S+" 00:00:00";
    SimpleDateFormat formatter = new SimpleDateFormat ("yyyy-MM-dd HH:mm:ss");
    ParsePosition pos = new ParsePosition(0);
    java.util.Date d=formatter.parse(S,pos);
    return d;
    }

    // �ж���һ��String  �Ƿ�ȵڶ���String  С

    static public  boolean compare(String a, String b)
    {
        return getdate(a).getTime()<getdate(b).getTime();
    }


    static public boolean compareequre(String a, String b)
    {
        return getdate(a).getTime()<=getdate(b).getTime();
    }


    static public  long DateDiff(char type,String S1,String S2)
    {
        boolean bIS = false;
        Date CurrentTime = new Date();
        Date dtBase = new Date();
        long ldiff_minute;
        CurrentTime=getdate(S1);
        dtBase=getdate(S2);
        ldiff_minute = (dtBase.getTime()-CurrentTime.getTime())/1000;
        return ldiff_minute;
    }

      //ȡ�����ڣ�������ʱ�䣩
    static public  String getDateString(String sValueDate)
    {
        String sYear="";
        String sMonthTemp="";
        String sMonth="";
        String sDayTemp="";
        String sDay="";
        String sHour="";
        String sMinute="";
        String sSecond="";
        int iTemp=0;
        if (sValueDate.length()>35)
        {
            sYear=sValueDate.substring(sValueDate.indexOf("YEAR=")+5,sValueDate.indexOf(",",sValueDate.indexOf("YEAR=")));
            sMonthTemp=sValueDate.substring(sValueDate.indexOf("MONTH=")+6,sValueDate.indexOf(",",sValueDate.indexOf("MONTH=")));
            iTemp=Integer.parseInt(sMonthTemp)+1;
            if (iTemp<10)
                sMonth="0"+(Integer.parseInt(sMonthTemp)+1)+"";
            else
                sMonth=(Integer.parseInt(sMonthTemp)+1)+"";
            sDayTemp=sValueDate.substring(sValueDate.indexOf("DAY_OF_MONTH=")+13,sValueDate.indexOf(",",sValueDate.indexOf("DAY_OF_MONTH=")));
            iTemp=Integer.parseInt(sDayTemp);
            if (iTemp<10)
                sDay="0"+(Integer.parseInt(sDayTemp))+"";
            else
                sDay=(Integer.parseInt(sDayTemp))+"";
        }

        //����С��35
        else
        {
            sMonth = getMonth(sValueDate.trim().substring(4,7));
            sDay = sValueDate.trim().substring(8,10);
            sYear =sValueDate.trim().substring(24,28);
        }
        sValueDate =sYear+"-"+sMonth+"-"+sDay;
        return sValueDate;
    }//public String getDateString(String sValueDate){

    //ȡ�����ڣ�����ʱ�䣩
    public static  String getDateTimeString(String sValueDate)
    {
        String sYear="";
        String sMonthTemp="";
        String sMonth="";
        String sDayTemp="";
        String sDay="";
        String sHourTemp="";
        String sHour="";
        String sMinuteTemp="";
        String sMinute="";
        String sSecondTemp="";
        String sSecond="";
        int iTemp=0;
        if (sValueDate.length()>35)
        {
            sYear=sValueDate.substring(sValueDate.indexOf("YEAR=")+5,sValueDate.indexOf(",",sValueDate.indexOf("YEAR=")));
          //month
            sMonthTemp=sValueDate.substring(sValueDate.indexOf("MONTH=")+6,sValueDate.indexOf(",",sValueDate.indexOf("MONTH=")));
            iTemp=Integer.parseInt(sMonthTemp)+1;

            if (iTemp<10)
                sMonth="0"+(Integer.parseInt(sMonthTemp)+1)+"";
            else
                sMonth=(Integer.parseInt(sMonthTemp)+1)+"";

          //day
            sDayTemp=sValueDate.substring(sValueDate.indexOf("DAY_OF_MONTH=")+13,sValueDate.indexOf(",",sValueDate.indexOf("DAY_OF_MONTH=")));
            iTemp=Integer.parseInt(sDayTemp);

            if (iTemp<10)
                sDay="0"+(Integer.parseInt(sDayTemp))+"";
            else
                sDay=(Integer.parseInt(sDayTemp))+"";

          //hour
            sHourTemp=sValueDate.substring(sValueDate.indexOf("HOUR_OF_DAY=")+12,sValueDate.indexOf(",",sValueDate.indexOf("HOUR_OF_DAY=")));
            iTemp=Integer.parseInt(sHourTemp);

            if (iTemp<10)
                sHour="0"+(Integer.parseInt(sHourTemp))+"";
            else
                sHour=(Integer.parseInt(sHourTemp))+"";

          //minute
            sMinuteTemp=sValueDate.substring(sValueDate.indexOf("MINUTE=")+7,sValueDate.indexOf(",",sValueDate.indexOf("MINUTE=")));
            iTemp=Integer.parseInt(sMinuteTemp);

            if (iTemp<10)
                sMinute="0"+(Integer.parseInt(sMinuteTemp))+"";
            else
                sMinute=(Integer.parseInt(sMinuteTemp))+"";

          //second
            sSecondTemp=sValueDate.substring(sValueDate.indexOf("SECOND=")+7,sValueDate.indexOf(",",sValueDate.indexOf("SECOND=")));
            iTemp=Integer.parseInt(sSecondTemp);

            if (iTemp<10)
                sSecond="0"+(Integer.parseInt(sSecondTemp))+"";
            else
                sSecond=(Integer.parseInt(sSecondTemp))+"";
        }

        //����С��35
        else
        {
            sMonth = getMonth(sValueDate.trim().substring(4,7));
            sDay = sValueDate.trim().substring(8,10);
            sYear =sValueDate.trim().substring(24,28);
            sHour =sValueDate.trim().substring(11,13);
            sMinute =sValueDate.trim().substring(14,16);
            sSecond =sValueDate.trim().substring(17,19);
        }
        sValueDate =sYear+"-"+sMonth+"-"+sDay+" "+sHour+":"+sMinute+":"+sSecond;
        return sValueDate;
    }

    public static  String getMonth(String mon)
    {
        String smon = new String();
        if (mon.equals("Jan")){smon = "01";}
        if (mon.equals("Feb")){smon = "02";}
        if (mon.equals("Mar")){smon = "03";}
        if (mon.equals("Apr")){smon = "04";}
        if (mon.equals("May")){smon = "05";}
        if (mon.equals("Jun")){smon = "06";}
        if (mon.equals("Jul")){smon = "07";}
        if (mon.equals("Aug")){smon = "08";}
        if (mon.equals("Sep")){smon = "09";}
        if (mon.equals("Oct")){smon = "10";}
        if (mon.equals("Nov")){smon = "11";}
        if (mon.equals("Dec")){smon = "12";}

        return smon;
    }

    public static  boolean isEmpty(String inputstr)
    {
        if(inputstr.compareTo("")==0||inputstr==null)
        {
            return true;
        }
        return false;
    }

     //0-16��0-F��ת��
    public static  String exchange(String sInput)
    {
        String sReturn=sInput;
        if(sInput.equals("10"))
        {
            sReturn="a";
        }
        else if(sInput.equals("11"))
        {
            sReturn="b";
        }
        else if(sInput.equals("12"))
        {
            sReturn="c";
        }else if(sInput.equals("13"))
        {
            sReturn="d";
        }else if(sInput.equals("14"))
        {
            sReturn="e";
        }
        else if(sInput.equals("15"))
        {
            sReturn="f";
        }
        return sReturn;
   }

  //*****�������������ǿ��Ի��16������������Ϊ��Ҫת����10����byte��****//
   public static  String get_H(byte bInput)
   {
        String sReturn="";
        String s1="";
        String s2="";
        if(bInput<0)  bInput+=128;
        s2=""+bInput%16;
        s2=exchange(s2);
        s1=""+(bInput-(bInput%16))/16;
        s1=exchange(s1);
        sReturn=s1+s2;
        return sReturn;
   }

   public static  long ByteConvert(byte Input)
   {
       if (Input>=0)
       {
           return (long)Input;
       }
       else
       {
           return (long)(256+Input);
       }
    }

    public static  int ByteToInt(byte Input)
    {
       if (Input>=0)
       {
           return (int)Input;
       }
       else
       {
           return (int)(256+Input);
       }
    }

   //�˷�����String����ת����byte����
   public static  byte get_byte(String sNumber)
   {
        //ȡ��16��������Ӧ��byteֵ
        byte bReturn=0;
        int iLength=0;
        iLength=sNumber.length();
        String sFirst="";//ʮλ��
        String sLast="";//��λ��
        if(iLength==2)
        {
            sFirst=sNumber.substring(0,1);
            sLast=sNumber.substring(1,2);
            bReturn=(byte)((get_value(sFirst))*16+(get_value(sLast)));
        }
        else if(iLength==1)
        {
            sLast=sNumber;
            bReturn=get_value(sLast);
        }
        return bReturn;
   }

   //16��������Ԫת����10����
   public static  byte get_value(String sInput)
   {
        byte bReturn=0;
        if(sInput.equals("0"))
        {
            bReturn=0;
        }
        else if(sInput.equals("1"))
        {
            bReturn=1;
        }
        else if(sInput.equals("2"))
        {
            bReturn=2;
        }else if(sInput.equals("3"))
        {
            bReturn=3;
        }
        else if(sInput.equals("4"))
        {
            bReturn=4;
        }
        else if(sInput.equals("5"))
        {
            bReturn=5;
        }
        else if(sInput.equals("6"))
        {
            bReturn=6;
        }
        else if(sInput.equals("7"))
        {
            bReturn=7;
        }
        else if(sInput.equals("8"))
        {
            bReturn=8;
        }
        else if(sInput.equals("9"))
        {
            bReturn=9;
        }
        else if(sInput.equals("a"))
        {
            bReturn=10;
        }
        else if(sInput.equals("b"))
        {
            bReturn=11;
        }
        else if(sInput.equals("c"))
        {
            bReturn=12;
        }
        else if(sInput.equals("d"))
        {
            bReturn=13;
        }
        else if(sInput.equals("e"))
        {
            bReturn=14;
        }
        else if(sInput.equals("f"))
        {
            bReturn=15;
        }
        return bReturn;
   }


  //��Χ���
    public static  boolean inRange(String inputstr,int lo,int hi)
    {
        int num=Integer.parseInt(inputstr);
        if(num<lo||num>hi)
        {
            return false;
        }
        return true;
    }

    public static  boolean isNumber(String inputstr)
    {
        String[] num={"0","1","2","3","4","5","6","7","8","9"};
        if(!isHave(num,inputstr))
            return false;
        else
            return true;
    }

    public static  boolean isHave(String[] words,String temp)
    {
        boolean have=true;
        boolean have_temp=true;
        int i,j;
        for(i=0;i<temp.length() ;i++)
        {
            String t=temp.substring(i,i+1);
            for(j=0;j<words.length ;j++)
            {
                have_temp=false;
                if(words[j].equals(t))
                {
                    have_temp=true;
                    break;
                }
            }
            if(!have_temp)
            {
                have=false;
                break;
            }
        }
        return have;
    }
//�·���Ч�Լ��
    public static  boolean validateMonth(String inputstr)
    {
        if(isEmpty(inputstr))
        {
            return false;
        }
        else
        {
            if(!isNumber(inputstr))
            {
                return false;
            }
            else
            {
               if(!inRange(inputstr,1,12))
               {
                    return false;
               }
            }
        }
        return true;
    }

//���ںϷ��Լ��
    public static  boolean validateDate(String inputstr,String yearstr,String monthstr)
    {
        if(isEmpty(inputstr))
        {
            return false;
        }
        else
        {
            if(!isNumber(inputstr))
            {
                return false;
            }
            else
            {
                if((!validateMonth(monthstr))||!(validateYear(yearstr))) return false;
                int monthVal=Integer.parseInt(monthstr);
                int yearRen=Integer.parseInt(yearstr);
                if(yearRen % 400 ==0 || (yearRen % 4 ==0 && yearRen % 100 !=0))
                {
               	    int monthMax[]={31,29,31,30,31,30,31,31,30,31,30,31};
                    int top=monthMax[monthVal];
                    if(!inRange(inputstr,1,top))
                    {
                        return false;
                    }
                }
                else
                {
               	    int monthMax[]={31,28,31,30,31,30,31,31,30,31,30,31};
                    int top=monthMax[monthVal];
                    if(!inRange(inputstr,1,top))
                    {
                        return false;
                    }
                }
            }
        }
        return true;
    }

//����Ч�Լ��
    public static  boolean validateYear(String inputstr)
    {
        if(isEmpty(inputstr))
        {
            return false;
        }
        else
        {
            if(!isNumber(inputstr))
            {
                return false;
            }
            else
            {
                if(!inRange(inputstr,2000,9998))
                {
                     return false;
                }
            }
        }
        return true;
    }

    //IP�Ϸ��Լ��
    public static  boolean validateIP(String inputstr)
    {
        boolean isIP=true;
        int dotcount=0;
        if(inputstr.length() >16||inputstr.length() <7)
            isIP=false;
        else
        {
            for(int i=0;i<inputstr.length() ;i++)
            {
                String t=inputstr.substring(i,i+1) ;
                if(t.compareTo(".")==0)
                     dotcount+=1;
            }
            if(dotcount<3||dotcount>3)
                isIP=false;
            else
            {
                StringTokenizer st;
                st=new StringTokenizer(inputstr,".");
                String[] sIP;
                sIP=new String[4];
                int i=0;
                while(st.hasMoreTokens()&&i<4)
                {
                    sIP[i]=st.nextToken() ;
           //         System.out.println(sIP[i]);
                }
              
                for(int j=0;j<4;j++)
                {
                   
                	
                	
                	if(!isNumber(sIP[i]))
                    {
                        isIP=false;
                        break;
                    }
                    else
                    {
                        int iIP=Integer.parseInt(sIP[i]);
                        if(j==0||j==3)
                        {
                            if(iIP<1||iIP>254)
                            {
                                isIP=false;
                                break;
                            }
                        }
                        else
                        {
                            if(iIP<0||iIP>255)
                            {
                                isIP=false;
                                break;
                            }
                        }
                    }
                }
            }
        }
        return isIP;
    }

}
