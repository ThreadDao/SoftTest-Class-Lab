package cast_client_server;

import java.awt.*;
import javax.swing.JPanel;
import java.sql.*;
import javax.swing.*;
import java.io.*;
import java.util.StringTokenizer;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class connDB {
  JOptionPane op = new JOptionPane();
  String sDBDriver = "oracle.jdbc.driver.OracleDriver";
  Connection conn = null;
  Statement stmt = null;
  ResultSet rs = null;
  String sIP = "";
  String sSID = "";
  String sUSER = "";
  String sPASS = "";

  public connDB() {
     String sConnStr ="";
        String sUsername="";
        String sPassword="";
        String sIP ="";
        String sSID ="";
        String sUSER ="";
        String sPASS ="";
        String FileName = ".\\ConnDBini.txt";

        try{
            BufferedReader reader = new BufferedReader(new FileReader(FileName));
            String line = reader.readLine();
            while(!(line.trim().equals("//�������ݿ����Ӵ�"))){
               line = reader.readLine();
            }
            if (line != null ){
                line = reader.readLine();
                StringTokenizer str = new StringTokenizer(line,"=");
                sIP = str.nextToken().trim();
                sIP = str.nextToken().trim();
                line = reader.readLine();
                str = new StringTokenizer(line,"=");
                sSID = str.nextToken().trim();
                sSID = str.nextToken().trim();
                line = reader.readLine();
                str = new StringTokenizer(line,"=");
                sUSER = str.nextToken().trim();
                sUSER = str.nextToken().trim();
                line = reader.readLine();
                str = new StringTokenizer(line,"=");
                sPASS = str.nextToken().trim();
                sPASS = str.nextToken().trim();
            }
            reader.close();
        }
        catch (Exception ioError){
        System.out.println("����ʼ�ļ�������" + ioError.getMessage());
        }
       sConnStr ="jdbc:oracle:thin:@" + sIP +":1521:" + sSID;
       sUsername = sUSER;
       sPassword = sPASS;
    try {
      Class.forName(sDBDriver);
      conn = DriverManager.getConnection(sConnStr,sUsername,sPassword);
      //stmt = conn.createStatement();
      jbInit();

    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  private void jbInit() throws Exception {

  }

}
