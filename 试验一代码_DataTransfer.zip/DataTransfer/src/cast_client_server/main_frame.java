/**
 * Title:        ����������ֹ�˾���оֵ������Ľӿڳ���
 * Description:
 * Copyright:    Copyright (c) 2002
 * Company:      ������Զ��Ϣ�������޹�˾
 * @author��     ����
 * @version��    1.0
 * StartDate:   2002/07/11
 * EndDate:     2002/07/12
 */

package cast_client_server;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.sql.*;
public class main_frame extends JFrame {
    JPanel contentPane;
    JMenuBar jMenuBar1 = new JMenuBar();
    JMenu jMenuFile = new JMenu();
    JMenuItem mExit = new JMenuItem();
    JMenu jMenuHelp = new JMenu();
    JMenuItem jMenuHelpAbout = new JMenuItem();
    JMenuItem mStart = new JMenuItem();
    main_panel clntPnl ;
    JPanel jPanel1 = new JPanel();
    BoxLayout2 boxLayout21 = new BoxLayout2();
    XYLayout xYLayout1 = new XYLayout();
    /**Construct the frame*/
    public main_frame() {
        enableEvents(AWTEvent.WINDOW_EVENT_MASK);
        try {
            jbInit();
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }
    /**Component initialization*/
    private void jbInit() throws Exception  {
        //setIconImage(Toolkit.getDefaultToolkit().createImage(main_frame.class.getResource("[Your Icon]")));
        contentPane = (JPanel) this.getContentPane();
        contentPane.setLayout(boxLayout21);
       this.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        this.setResizable(false);
        this.setSize(new Dimension(1020,740));
        this.setTitle("����������ֹ�˾���е������Ľӿڳ���");

        jMenuFile.setText("ϵͳ");
        mExit.setText("�˳�");
        mExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mExit_actionPerformed(e);
            }
        });


        jMenuHelp.setText("����");
        jMenuHelpAbout.setText("����");
        jMenuHelpAbout.addActionListener(new ActionListener()  {
            public void actionPerformed(ActionEvent e) {
                jMenuHelpAbout_actionPerformed(e);
            }
        });
        mStart.setText("����");
        mStart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mStart_actionPerformed(e);
            }
        });


        jPanel1.setLayout(xYLayout1);
        jMenuFile.add(mStart);
        jMenuFile.add(mExit);
        jMenuHelp.add(jMenuHelpAbout);
        jMenuBar1.add(jMenuFile);
        jMenuBar1.add(jMenuHelp);
        contentPane.add(jPanel1, null);
        this.setJMenuBar(jMenuBar1);
    }
    /**File | Exit action performed*/

    /**Help | About action performed*/
    public void jMenuHelpAbout_actionPerformed(ActionEvent e) {
        main_frame_AboutBox dlg = new main_frame_AboutBox(this);
        Dimension dlgSize = dlg.getPreferredSize();
        Dimension frmSize = getSize();
        Point loc = getLocation();
        dlg.setLocation((frmSize.width - dlgSize.width) / 2 + loc.x, (frmSize.height - dlgSize.height) / 2 + loc.y);
        dlg.setModal(true);
        dlg.show();
    }
    /**Overridden so we can exit when window is closed*/

    protected void processWindowEvent(WindowEvent e) {
        super.processWindowEvent(e);
        if (e.getID() == WindowEvent.WINDOW_CLOSING) {
        mExit_actionPerformed(null);
        }
    }


    void mStart_actionPerformed(ActionEvent e) {
     clntPnl = new main_panel();
        jPanel1.removeAll();
        jPanel1.add(clntPnl, new XYConstraints(-1, -1, 1024, 765));
        jPanel1.revalidate();
        jPanel1.repaint();

    }

    void mExit_actionPerformed(ActionEvent e) {

             int iOption = JOptionPane.showConfirmDialog(this,"�Ƿ�ȷ���˳���","ע��",JOptionPane.YES_NO_OPTION);
            if(iOption == JOptionPane.YES_OPTION)
            {
                if(clntPnl == null)
                {

                    System.exit(0);
                }
                else
                {

                    System.exit(0);
                }
            }

    }


}