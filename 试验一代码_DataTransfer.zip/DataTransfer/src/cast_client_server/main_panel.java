/**
 * Title:        ����������ֹ�˾���оֵ������Ľӿڳ���
 * Description:
 * Copyright:    Copyright (c) 2002
 * Company:      ������Զ��Ϣ�������޹�˾
 * @author��     ����
 * @version��    1.0
 * StartDate:   2002/07/11
 * EndDate:
 */

package cast_client_server;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import javax.swing.border.*;
import java.awt.event.*;
import java.net.*;
import java.sql.*;
import java.io.*;
import java.beans.*;
import java.util.Vector;
import java.util.StringTokenizer;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.*;

public class main_panel extends JPanel {


    //�Զ������
    //=========================================================================
    private String sSendIP="";//�Է�IP
    private String sHostName="";//������
    private String sObjectName="";//
    //�������ݲ�������
    private String sTimeGap="60";//ʱ����
    private String sStartYear="";//��ʼ��
    private String sStartMonth="";//��ʼ��
    private String sStartDay="";//��ʼ��
    private String sStartHour="";//��ʼʱ
    private String sStartMinute="00";//��ʼ��
    private String sStartSecond="00";//��ʼ��
    private String sEndYear="";//������
    private String sEndMonth="";//������
    private String sEndDay="";//������
    private String sEndHour="";//����ʱ
    private String sEndMinute="00";//������
    private String sEndSecond="00";//������

    private String sATimeGap="60";//ʱ����
    private String sAStartYear="";//�Զ���ʼ��
    private String sAStartMonth="";//�Զ���ʼ��
    private String sAStartDay="";//�Զ���ʼ��
    private String sAStartHour="";//�Զ���ʼʱ
    private String sAStartMinute="00";//�Զ���ʼ��
    private String sAStartSecond="00";//�Զ���ʼ��
    private String sAEndYear="";//�Զ�������
    private String sAEndMonth="";//�Զ�������
    private String sAEndDay="";//�Զ�������
    private String sAEndHour="";//�Զ�����ʱ
    private String sAEndMinute="00";//�Զ�������
    private String sAEndSecond="00";//�Զ�������
    private String sStartDate;//��ʼʱ��
    private String sEndDate;//����ʱ��
    private int isParamSave=0;//���������־��0��û�б��棻1Ϊ����
    private int isClientAuto=0;//���������Զ�ִ�б�־��1Ϊ�Զ���2Ϊ�ֶ�;0Ϊֹͣ
    private int isServerAuto=0;//���������Զ�ִ�б�־��1Ϊ�Զ���0Ϊֹͣ
    private String sAutoTime="";//�Զ���������ʱ��
    private boolean isCSuccess=false;//����ɹ���ʶ
    private int iDataCount=0;//�Ƿ������ݽ��ձ�ʶ
    private int iUpdate=0;//�Ƿ񸲸Ǳ�ʶ��0�����ǣ�1����
    private String sDateFrom="1900-01-01 00:00:00";//��ʼ���ݿ�ʱ��
    private String sDateTo="1900-01-01 00:00:01";//�������ݿ�ʱ��
    private int iFrameNo=0;
    private int iBMCount=0;
    private int iDLCount=0;
    private int iTotalCount=0;
    private int iBM=0;
    private int iDL=0;
    private String sType="1";
    private String[] sBMIndex_name;
    private int[] iBMIndex_no;
    private String[] sDLIndex_name;
    private int[] iDLIndex_no;
    private String[] sTotalIndex_name;
    private int[] iTotalIndex_no;
    private Vector vBMList = new Vector();
    private Vector vDLList = new Vector();
    private JList lstBMSelect ;
    private JList lstDLSelect ;

    //����socket�׽���
    Socket sktConnect;
    //�����壬socket�������������Ҫת��Ϊ�������������
    InputStream ips_Client;
    DataInputStream dips_Client;
    OutputStream ops_Client;
    DataOutputStream dops_Client;
    //���ݿ�������壬connDB1�����ݿ�
    connDB connDB1;
    Connection con=null;
    java.sql.Statement stmt_Client=null;

    Vector error_name=null;
    Vector right_name=null;

    ClientAutoStart cat=null;
    ServerAutoStart sat=null;

   //�Զ����������
   //==========================================================================

    //ϵͳ�������
    //=========================================================================
    BorderLayout borderLayout1 = new BorderLayout();
    JTabbedPane jTabbedPane1 = new JTabbedPane();
    JPanel jPanel1 = new JPanel();
    JPanel jPanel2 = new JPanel();
    JPanel jPanel3 = new JPanel();
    XYLayout xYLayout1 = new XYLayout();
    XYLayout xYLayout3 = new XYLayout();
    JLabel jLabel1 = new JLabel();
    JComboBox cmbObject = new JComboBox();
    JLabel jLabel2 = new JLabel();
    JTextField txtSIP = new JTextField();
    JLabel jLabel3 = new JLabel();
    JTextField txtGName = new JTextField();
    JLabel jLabel4 = new JLabel();
    JComboBox cmbTimeGap = new JComboBox();
    JLabel jLabel5 = new JLabel();
    JLabel jLabel6 = new JLabel();
    JPanel jPanel4 = new JPanel();
    XYLayout xYLayout4 = new XYLayout();
    TitledBorder titledBorder1;
    JTextField txtStartYear = new JTextField();
    JTextField txtStartMonth = new JTextField();
    JLabel jLabel7 = new JLabel();
    JTextField txtStartDay = new JTextField();
    JComboBox cmbStartHour = new JComboBox();
    JLabel jLabel8 = new JLabel();
    JLabel jLabel9 = new JLabel();
    JLabel jLabel10 = new JLabel();
    JLabel jLabel11 = new JLabel();
    JTextField txtEndDay = new JTextField();
    JTextField txtEndYear = new JTextField();
    JComboBox cmbEndHour = new JComboBox();
    JLabel jLabel12 = new JLabel();
    JLabel jLabel13 = new JLabel();
    JLabel jLabel14 = new JLabel();
    JLabel jLabel15 = new JLabel();
    JTextField txtEndMonth = new JTextField();

    JButton btnSave = new JButton();
    XYLayout xYLayout2 = new XYLayout();
    JPanel jPanel5 = new JPanel();
    Border border1;
    TitledBorder titledBorder2;
    XYLayout xYLayout5 = new XYLayout();
    JPanel jPanel6 = new JPanel();
    TitledBorder titledBorder3;
    JPanel jPanel7 = new JPanel();
    TitledBorder titledBorder4;
    JPanel jPanel8 = new JPanel();
    TitledBorder titledBorder5;
    XYLayout xYLayout6 = new XYLayout();
    XYLayout xYLayout7 = new XYLayout();
    XYLayout xYLayout8 = new XYLayout();
    JScrollPane jScrollPane1 = new JScrollPane();
    JButton btnBMSelectAll = new JButton();
    TitledBorder titledBorder6;
    JButton btnAutoStart = new JButton();
    JButton btnAutoStop = new JButton();
    JButton btnHandStart = new JButton();
    JButton btnHandStop = new JButton();
    JScrollPane jScrollPane2 = new JScrollPane();
    JScrollPane jScrollPane3 = new JScrollPane();
    JLabel jLabel17 = new JLabel();
    JLabel jLabel18 = new JLabel();
    JTextArea txtarCode = new JTextArea();
    JTextArea txtarExplain = new JTextArea();
    JPanel jPanel9 = new JPanel();
    TitledBorder titledBorder7;
    XYLayout xYLayout9 = new XYLayout();
    JPanel jPanel10 = new JPanel();
    TitledBorder titledBorder8;
    XYLayout xYLayout10 = new XYLayout();
    JPanel jPanel11 = new JPanel();
    TitledBorder titledBorder9;
    TitledBorder titledBorder10;
    XYLayout xYLayout12 = new XYLayout();
    JPanel jPanel13 = new JPanel();
    TitledBorder titledBorder11;
    XYLayout xYLayout13 = new XYLayout();
    JLabel jLabel19 = new JLabel();
    JPanel jPanel15 = new JPanel();
    TitledBorder titledBorder12;
    JLabel jLabel110 = new JLabel();
    XYLayout xYLayout14 = new XYLayout();
    JPanel jPanel16 = new JPanel();
    JPanel jPanel17 = new JPanel();
    TitledBorder titledBorder13;
    XYLayout xYLayout15 = new XYLayout();
    JLabel jLabel20 = new JLabel();
    XYLayout xYLayout16 = new XYLayout();
    JButton btnAutoSend = new JButton();
    JButton btnAutoSendStop = new JButton();
    JScrollPane jScrollPane4 = new JScrollPane();
    JScrollPane jScrollPane5 = new JScrollPane();
    JTextArea txtarSExplain = new JTextArea();
    JTextArea txtarSCode = new JTextArea();
    JCheckBox ckbBM = new JCheckBox();
    JScrollPane jScrollPane6 = new JScrollPane();
    JCheckBox ckbDL = new JCheckBox();
    JButton btnDLSelectAll = new JButton();
    JButton btnBMClear = new JButton();
    JButton btnDLClear = new JButton();
    JButton btnSClear = new JButton();
    JComboBox cmbAutoTime = new JComboBox();
    JLabel jLabel16 = new JLabel();
    JLabel jLabel21 = new JLabel();
    JLabel jLabel22 = new JLabel();
    JCheckBox ckUpdate = new JCheckBox();
   //ϵͳ�����������
   //==========================================================================


    public main_panel() {
        try {
            jbInit();
            SetJListView();
            cmbTimeGap.setSelectedIndex(0) ;
            cmbStartHour.setSelectedIndex(0) ;
            cmbEndHour.setSelectedIndex(0) ;
            cmbObject.setSelectedIndex(0) ;
            cmbAutoTime.setSelectedIndex(5);
            String sIStartDate;
            String sIEndDate;
            Date date;
            date=new java.util.Date();
            sIEndDate=CommFunc.getDateTimeString(date.toString() );
            sIStartDate=CommFunc.DateAdd("DD",-1,sIEndDate) ;
            String sIStartYear=sIStartDate.substring(0,4);
            String sIStartMonth=sIStartDate.substring(5,7) ;
            String sIStartDay=sIStartDate.substring(8,10) ;
            String sIEndYear=sIEndDate.substring(0,4) ;
            String sIEndMonth=sIEndDate.substring(5,7) ;
            String sIEndDay=sIEndDate.substring(8,10) ;
            txtStartYear.setText(sIStartYear) ;
            txtStartMonth.setText(sIStartMonth) ;
            txtStartDay.setText(sIStartDay) ;
            txtEndYear.setText(sIEndYear) ;
            txtEndMonth.setText(sIEndMonth) ;
            txtEndDay.setText(sIEndDay) ;

        }
        catch(Exception ex) {
            ex.printStackTrace();
        }
    }
    void jbInit() throws Exception {

        titledBorder1 = new TitledBorder("");
        border1 = BorderFactory.createEmptyBorder();
        titledBorder2 = new TitledBorder("");
        titledBorder3 = new TitledBorder("");
        titledBorder4 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(148, 145, 140)),"Դ�뼰����");
        titledBorder5 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(148, 145, 140)),"������ʽѡ��");
        titledBorder6 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(148, 145, 140)),"��·ѡ��");
        titledBorder7 = new TitledBorder("");
        titledBorder8 = new TitledBorder("");
        titledBorder9 = new TitledBorder("");
        titledBorder10 = new TitledBorder("");
        titledBorder11 = new TitledBorder("");
        titledBorder12 = new TitledBorder("");
        titledBorder13 = new TitledBorder("");
        this.setLayout(borderLayout1);
        this.setSize(1010,720);
        jPanel1.setLayout(xYLayout1);
        jPanel2.setLayout(xYLayout2);
        jPanel3.setLayout(xYLayout3);
        jLabel1.setText("ȡ������");
        jLabel2.setText("�Է�IP");
        jLabel3.setText("������");
        jLabel4.setText("ʱ����");
        jLabel5.setText("����");
        jLabel6.setText("��ʼʱ��");
        jPanel4.setLayout(xYLayout4);
        jPanel4.setBorder(titledBorder1);
        jLabel7.setText("��");
        jLabel8.setText("��");
        jLabel9.setText("��");
        jLabel10.setText("ʱ");
        jLabel11.setText("ʱ");
        jLabel12.setText("��");
        jLabel13.setText("��");
        jLabel14.setText("��");
        jLabel15.setText("����ʱ��");
        btnSave.setText(" ��    ��");
        btnSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                btnSave_actionPerformed(e);
            }
        });
        cmbObject.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(ItemEvent e) {
                cmbObject_itemStateChanged(e);
            }
        });
        jPanel5.setBorder(titledBorder2);
        jPanel5.setLayout(xYLayout5);
        jPanel6.setBorder(titledBorder6);
        jPanel6.setLayout(xYLayout6);
        jPanel7.setBorder(titledBorder4);
        jPanel7.setLayout(xYLayout8);
        jPanel8.setBorder(titledBorder5);
        jPanel8.setLayout(xYLayout7);
        btnBMSelectAll.setActionCommand("btnBMSelectAll");
        btnBMSelectAll.setText("ȫ ѡ");
        btnBMSelectAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                btnBMSelectAll_actionPerformed(e);
            }
        });
        btnAutoStart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                btnAutoStart_actionPerformed(e);
            }
        });
        btnAutoStart.setText("��   ��");
        btnAutoStart.setActionCommand("btnRefresh");
        btnAutoStop.setActionCommand("btnRefresh");
        btnAutoStop.setText("�Զ�ֹͣ");
        btnAutoStop.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                btnAutoStop_actionPerformed(e);
            }
        });
        btnHandStart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                btnHandStart_actionPerformed(e);
            }
        });
        btnHandStart.setText("��   ��");
        btnHandStart.setActionCommand("btnRefresh");
        btnHandStop.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                btnHandStop_actionPerformed(e);
            }
        });
        btnHandStop.setText("�ֶ�ֹͣ");
        btnHandStop.setActionCommand("btnRefresh");
        jLabel17.setText("ͨѶԴ����");
        jLabel18.setText("���ͽ��");
        txtarCode.setBackground(SystemColor.info);
        txtarCode.setEditable(false);
        txtarCode.setLineWrap(true);
        txtarCode.setWrapStyleWord(true);
        txtarExplain.setBackground(SystemColor.info);
        txtarExplain.setEditable(false);
        txtarExplain.setColumns(100);
        txtarExplain.setLineWrap(true);
        txtarExplain.setRows(10);
        txtarExplain.setWrapStyleWord(true);
        txtGName.setText("������վ�ͻ���");
        jPanel9.setBorder(titledBorder7);
        jPanel9.setLayout(xYLayout9);
        jPanel10.setBorder(titledBorder8);
        jPanel10.setLayout(xYLayout10);
        jPanel11.setBorder(titledBorder9);
        jPanel11.setLayout(xYLayout12);
        jPanel13.setBorder(titledBorder11);
        jPanel13.setLayout(xYLayout13);
        jLabel19.setText("������ʽ");
        jPanel15.setBorder(titledBorder12);
        jPanel15.setLayout(xYLayout15);
        jLabel110.setText("���ͽ��");
        jPanel16.setLayout(xYLayout14);
        jPanel16.setBorder(titledBorder11);
        jPanel17.setBorder(titledBorder13);
        jPanel17.setLayout(xYLayout16);
        jLabel20.setText("ͨѶԴ����");
        btnAutoSend.setText("�Զ�����");
        btnAutoSend.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                btnAutoSend_actionPerformed(e);
            }
        });
        btnAutoSendStop.setText("ֹͣ����");
        btnAutoSendStop.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                btnAutoSendStop_actionPerformed(e);
            }
        });
        txtarSExplain.setBackground(SystemColor.info);
        txtarSExplain.setEditable(false);
        txtarSExplain.setWrapStyleWord(true);
        txtarSCode.setBackground(SystemColor.info);
        txtarSCode.setEditable(false);
        txtarSCode.setWrapStyleWord(true);
        cmbTimeGap.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(ItemEvent e) {
                cmbTimeGap_itemStateChanged(e);
            }
        });
        ckbBM.setText("����");
        ckbDL.setText("����");
        btnDLSelectAll.setActionCommand("btnDLSelectAll");
        btnDLSelectAll.setText("ȫѡ");
        btnDLSelectAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                btnDLSelectAll_actionPerformed(e);
            }
        });
        txtSIP.setText("10.12.1.101");
        btnBMClear.setText("���");
        btnBMClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                btnBMClear_actionPerformed(e);
            }
        });
        btnDLClear.setActionCommand("btnDLClear");
        btnDLClear.setText("���");
        btnDLClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                btnDLClear_actionPerformed(e);
            }
        });
        btnSClear.setText("��  ��");
        btnSClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                btnSClear_actionPerformed(e);
            }
        });
        jLabel16.setText("�Զ���������ʱ��");
        jLabel21.setText("ʱ");
        jLabel22.setText("�Ƿ񸲸���������");
        ckUpdate.setText("  ����");
        this.add(jTabbedPane1, BorderLayout.CENTER);
        jTabbedPane1.add(jPanel1,    "��������");
        jPanel1.add(jPanel4,        new XYConstraints(214, 112, 590, 466));
        jTabbedPane1.add(jPanel2,   "��������");
        jPanel2.add(jPanel5,          new XYConstraints(21, 16, 962, 625));
        jPanel5.add(jPanel7,          new XYConstraints(463, 16, 474, 581));
        jPanel7.add(jScrollPane2,     new XYConstraints(19, 37, 425, 236));
        jPanel7.add(jPanel9,   new XYConstraints(18, 0, 425, 29));
        jPanel9.add(jLabel17,   new XYConstraints(-1, 0, -1, -1));
        jPanel7.add(jScrollPane3, new XYConstraints(17, 324, 422, 215));
        jPanel7.add(jPanel10, new XYConstraints(16, 289, 423, 29));
        jPanel10.add(jLabel18,   new XYConstraints(-2, 0, -1, -1));
        jScrollPane3.getViewport().add(txtarExplain, null);
        jScrollPane2.getViewport().add(txtarCode, null);
        jPanel5.add(jPanel6,       new XYConstraints(9, 16, 437, 444));
        jPanel6.add(jScrollPane1,                new XYConstraints(14, 51, 191, 348));
        jTabbedPane1.add(jPanel3,   "��������");
        jPanel3.add(jPanel11,         new XYConstraints(28, 18, 947, 608));
        jPanel17.add(btnAutoSend,       new XYConstraints(28, 31, 84, 28));
        jPanel17.add(btnAutoSendStop,      new XYConstraints(162, 31, 84, 28));
        jPanel17.add(btnSClear,   new XYConstraints(299, 30, 84, 28));
        jPanel11.add(jPanel13,   new XYConstraints(25, 445, 435, 31));
        jPanel13.add(jLabel19, new XYConstraints(7, 1, 94, 19));
        jPanel11.add(jPanel15, new XYConstraints(480, 12, 438, 31));
        jPanel15.add(jLabel20, new XYConstraints(2, 2, 111, 19));
        jPanel11.add(jPanel16, new XYConstraints(23, 13, 438, 31));
        jPanel16.add(jLabel110, new XYConstraints(7, 1, 94, 19));
        jPanel11.add(jScrollPane4,  new XYConstraints(23, 59, 438, 368));
        jPanel11.add(jScrollPane5, new XYConstraints(482, 60, 438, 520));
        jPanel11.add(jPanel17, new XYConstraints(24, 485, 436, 93));
        jScrollPane5.getViewport().add(txtarSCode, null);
        jScrollPane4.getViewport().add(txtarSExplain, null);
        jPanel4.add(txtStartYear,      new XYConstraints(148, 226, 47, 26));
        jPanel4.add(cmbObject,      new XYConstraints(148, 53, 113, 26));
        jPanel4.add(jLabel14,        new XYConstraints(217, 312, 23, 34));
        jPanel4.add(txtEndYear,  new XYConstraints(148, 312, 45, 26));
        jPanel4.add(jLabel7,   new XYConstraints(218, 226, 18, 34));
        jPanel4.add(txtStartMonth,     new XYConstraints(247, 226, 28, 26));
        jPanel4.add(jLabel8,   new XYConstraints(295, 226, 28, 34));
        jPanel4.add(jLabel9,   new XYConstraints(380, 226, 24, 34));
        jPanel4.add(cmbStartHour,    new XYConstraints(419, 226, 52, 26));
        jPanel4.add(jLabel10,   new XYConstraints(481, 226, 29, 34));
        jPanel4.add(txtStartDay,  new XYConstraints(331, 226, 28, 26));
        jPanel4.add(cmbEndHour,    new XYConstraints(419, 312, 52, 26));
        jPanel4.add(jLabel11,   new XYConstraints(481, 312, 29, 34));
        jPanel4.add(jLabel1,  new XYConstraints(95, 53, 58, 34));
        jPanel4.add(jLabel15, new XYConstraints(91, 308, 61, 34));
        jPanel4.add(jLabel2, new XYConstraints(91, 138, 48, 34));
        jPanel4.add(jLabel6, new XYConstraints(91, 226, 61, 34));
        jPanel4.add(txtEndMonth,     new XYConstraints(248, 312, 28, 26));
        jPanel4.add(txtEndDay,     new XYConstraints(328, 312, 28, 26));
        jPanel4.add(jLabel12,     new XYConstraints(380, 312, 18, 34));
        jPanel4.add(jLabel13,  new XYConstraints(298, 312, 27, 34));
        jPanel4.add(txtSIP,    new XYConstraints(149, 138, 109, 26));
        jPanel4.add(jLabel3,  new XYConstraints(321, 53, 53, 34));
        jPanel4.add(txtGName,  new XYConstraints(371, 53, 123, 26));
        jPanel4.add(btnSave,    new XYConstraints(395, 393, 82, 28));
        jPanel4.add(jLabel5, new XYConstraints(470, 134, 38, 34));
        jPanel4.add(cmbTimeGap, new XYConstraints(393, 138, 64, 26));
        jPanel4.add(jLabel4, new XYConstraints(320, 135, 62, 34));
        jPanel4.add(jLabel16,  new XYConstraints(89, 395, 106, 28));
        jPanel4.add(cmbAutoTime, new XYConstraints(222, 395, 54, 25));
        jPanel4.add(jLabel21,     new XYConstraints(297, 397, 30, 26));
        jPanel5.add(jPanel8,   new XYConstraints(9, 473, 439, 123));
        jPanel8.add(btnAutoStart, new XYConstraints(25, 10, 85, 27));
        jPanel8.add(btnAutoStop, new XYConstraints(22, 60, 84, 27));
        jPanel8.add(btnHandStart,  new XYConstraints(170, 10, 84, 27));
        jPanel8.add(btnHandStop,  new XYConstraints(170, 61, 84, 27));
        jPanel8.add(ckUpdate,  new XYConstraints(303, 59, 65, 27));
        jPanel8.add(jLabel22, new XYConstraints(297, 13, 104, 26));
        jPanel6.add(jScrollPane6,        new XYConstraints(223, 51, 191, 348));
        jPanel6.add(ckbDL,   new XYConstraints(225, 10, 57, 24));
        jPanel6.add(btnBMClear,   new XYConstraints(75, 10, 61, 23));
        jPanel6.add(ckbBM, new XYConstraints(14, 10, 47, 27));
        jPanel6.add(btnBMSelectAll,     new XYConstraints(148, 10, 61, 23));
        jPanel6.add(btnDLSelectAll,      new XYConstraints(353, 10, 63, 24));
        jPanel6.add(btnDLClear,  new XYConstraints(283, 10, 63, 24));
        btnAutoSendStop.setEnabled(false) ;
        for(int i=0;i<10;i++)
        {
            cmbStartHour.addItem("0"+i);
            cmbEndHour.addItem("0"+i);
            cmbAutoTime.addItem("0"+i);
        }

        for(int i=10;i<24;i++)
        {
            cmbStartHour.addItem(""+i);
            cmbEndHour.addItem(""+i);
            cmbAutoTime.addItem(""+i);
        }


        cmbObject.addItem("�е�������");
        cmbObject.addItem("����");
        cmbTimeGap.addItem("60");
        cmbTimeGap.addItem("120");

        connDB1 = new connDB();
        con=connDB1.conn ;

        btnAutoStop.setEnabled(false) ;
        btnHandStop.setEnabled(false) ;
    }

    void btnSave_actionPerformed(ActionEvent e)
    {
        sStartYear=txtStartYear.getText().trim() ;
        sStartMonth=txtStartMonth.getText().trim() ;
        sStartDay=txtStartDay.getText().trim() ;
        sStartHour=cmbStartHour.getSelectedItem().toString()  ;
        sEndYear=txtEndYear.getText().trim() ;
        sEndMonth=txtEndMonth.getText().trim() ;
        sEndDay=txtEndDay.getText().trim() ;
        sEndHour=cmbEndHour.getSelectedItem().toString() ;
        sAutoTime=cmbAutoTime.getSelectedItem().toString().trim() ;
        sAutoTime=sAutoTime+":"+"00";
        if(sStartMonth.length() ==1)
            sStartMonth="0"+sStartMonth;
        if(sStartDay.length() ==1)
            sStartDay="0"+sStartDay;
        if(sEndMonth.length() ==1)
            sEndMonth="0"+sEndMonth;
        if(sEndDay.length() ==1)
            sEndDay="0"+sEndDay;
        sStartDate=sStartYear+"-"+sStartMonth+"-"+sStartDay+" "+sStartHour +":00:00";
        sEndDate=sEndYear+"-"+sEndMonth+"-"+sEndDay+" "+sEndHour +":00:00";
        if(txtGName.getText().trim().compareTo("")==0||txtGName.getText().trim()==null)
        {
            JOptionPane.showMessageDialog(this,"��������������","����",JOptionPane.OK_OPTION);
        }
        if(CommFunc.validateIP(txtSIP.getText().trim() ))
        {
            if(CommFunc.validateYear(sStartYear)&&CommFunc.validateYear(sEndYear))
            {
                if(CommFunc.validateMonth(sStartMonth)&&CommFunc.validateMonth(sEndMonth))
                {
                    if(CommFunc.validateDate(sStartDay,sStartYear,sStartMonth)&&CommFunc.validateDate(sEndDay,sEndYear,sEndMonth))
                    {

                         if(CommFunc.compare(sStartDate,sEndDate) )
                         {
                            isParamSave=1;
                            sHostName=txtGName.getText().trim() ;
                            sSendIP=txtSIP.getText().trim() ;
                            sObjectName=cmbObject.getSelectedItem().toString()  ;
                            sTimeGap=cmbTimeGap.getSelectedItem().toString() ;
                            JOptionPane.showMessageDialog(this,"�����Ѿ����棡","ע��",JOptionPane.DEFAULT_OPTION);


                         }
                         else
                         {

                            JOptionPane.showMessageDialog(this,"����ʱ��С�ڿ�ʼʱ�䣡","����",JOptionPane.OK_OPTION);
                         }//��ʼʱ�������ʱ���С�Ƚ�
                    }
                    else
                    {
                        JOptionPane.showMessageDialog(this,"���������","����",JOptionPane.OK_OPTION);
                    }//����Ч�Լ��
                }
                else
                {
                    JOptionPane.showMessageDialog(this,"�·��������","����",JOptionPane.OK_OPTION);
                }//����Ч�Լ��
            }
            else
            {
                JOptionPane.showMessageDialog(this,"���������","����",JOptionPane.OK_OPTION);
            }//����Ч�Լ��
        }
        else
        {
            JOptionPane.showMessageDialog(this,"�Է�����IP��ַ�������","����",JOptionPane.OK_OPTION);
        }//IP��Ч�Լ��

    }

    void cmbObject_itemStateChanged(ItemEvent e) {
        if(cmbObject.getSelectedIndex() ==0)
        {
            txtSIP.setText("10.12.1.101") ;
        }
    }

     //����������ѡ���������Ͳ���ʾ��JList�У�����Ϊ���ƣ�0Ϊѡ�������·��1Ϊѡ�������·
    public void SetJListView()
    {

        /*
    	java.sql.Statement stmtLine;

        ResultSet rsBM;
        ResultSet rsDL;
        String sBMSql="";
        String sDLSql="";

        try
        {
            //ִ�����ݿ����
            stmtLine=con.createStatement() ;

            sBMSql = "select distinct POINT_NAME,POINT_DES,MIS_NO from point_index where serial_no<79";

            sDLSql = "select distinct POINT_NAME,POINT_DES,MIS_NO from point_index where serial_no>78";

            rsBM = stmtLine.executeQuery(sBMSql);

            if(!vBMList.isEmpty() )
               vBMList.removeAllElements() ;
            while(rsBM.next())
            {
                vBMList.addElement(""+rsBM.getString("POINT_NAME")+"|"+rsBM.getInt("MIS_NO"));
            }
              //��VECTOR���������ӵ�JList��
            lstBMSelect = new JList(vBMList);
            if(!vDLList.isEmpty() )
                vDLList.removeAllElements() ;
            rsDL = stmtLine.executeQuery(sDLSql);
            while(rsDL.next() )
            {
                vDLList.addElement(""+rsBM.getString("POINT_NAME")+"|"+rsBM.getInt("MIS_NO"));
            }
            lstDLSelect = new JList(vDLList);
            jScrollPane1.getViewport().add(lstBMSelect, null);
            jScrollPane6.getViewport().add(lstDLSelect, null);
            jPanel2.revalidate();
            jPanel2.repaint();
            if (rsDL!=null)
            {
                rsDL.close();
                rsDL=null;
            }
            if (rsBM!=null)
            {
                rsBM.close();
                rsBM=null;
            }
            if (stmtLine!=null)
            {
                stmtLine.close();
                stmtLine=null;
            }

        }
        catch(Exception se1)
        {
              JOptionPane.showMessageDialog(this,"�޷�ִ�����ݿ������"+se1.toString() ,"ע��",JOptionPane.ERROR_MESSAGE);

        }
       */
    }


    void btnAutoStart_actionPerformed(ActionEvent e) {

    try
    {
        if(!ckbBM.isSelected() &&!ckbDL.isSelected() )
        {
            JOptionPane.showMessageDialog(this,"û��ѡ���������ͣ� ����������","����",JOptionPane.ERROR_MESSAGE);

        }

        if(isParamSave!=1)
        {
            JOptionPane.showMessageDialog(this,"û�����ò�����","����",JOptionPane.ERROR_MESSAGE);
             if(true) return;
        }

        if(ckbBM.isSelected() )
        {
            if(lstBMSelect.getSelectedIndices().length == 0)
            {
                JOptionPane.showMessageDialog(this,"����û��ѡ��һ����·��","����",JOptionPane.ERROR_MESSAGE);
                if(true) return;
            }
            iBM=1;
            iBMCount = lstBMSelect.getSelectedIndices().length;
            //iBMIndex_no����Ϊѡ����·������������
            iBMIndex_no = new int[iBMCount];
            sBMIndex_name = new String[iBMCount];
            String sBMIndex_no = "";
            for(int i=0; i<iBMCount; i++)
            {
                sBMIndex_no = "" + lstBMSelect.getSelectedValues()[i];
                StringTokenizer str = new StringTokenizer(sBMIndex_no,"|");
                sBMIndex_no = str.nextToken().trim();
                sBMIndex_name[i] = sBMIndex_no;
                iBMIndex_no[i] = Integer.parseInt(str.nextToken().trim());
            }
        }
        else
        {
            iBMCount=0;
        }
        if(ckbDL.isSelected() )
        {
            if(lstDLSelect.getSelectedIndices().length == 0)
            {
                JOptionPane.showMessageDialog(this,"����û��ѡ��һ����·��","����",JOptionPane.ERROR_MESSAGE);
                if(true) return;
            }

            iDL=1;
            iDLCount = lstDLSelect.getSelectedIndices().length;
            //iBMIndex_no����Ϊѡ����·������������
            iDLIndex_no = new int[iDLCount];
            sDLIndex_name = new String[iDLCount];
            String sDLIndex_no = "";
            for(int i=0; i<iDLCount; i++)
            {
                sDLIndex_no = "" + lstDLSelect.getSelectedValues()[i];
                StringTokenizer str = new StringTokenizer(sDLIndex_no,"|");
                sDLIndex_no = str.nextToken().trim();
                sDLIndex_name[i] = sDLIndex_no;
                iDLIndex_no[i] = Integer.parseInt(str.nextToken().trim());
            }
        }
        else
        {
            iDLCount=0;
        }
        if(ckUpdate.isSelected() )
        {
            iUpdate=1;
        }
        else
        {
            iUpdate=0;
        }
        isClientAuto=1;
        btnSave.setEnabled(false) ;
        btnBMSelectAll.setEnabled(false) ;
        btnDLSelectAll.setEnabled(false) ;
        btnAutoStart.setEnabled(false) ;
        btnHandStart.setEnabled(false) ;
        btnAutoStop.setEnabled(true) ;
        btnBMClear.setEnabled(false) ;
        btnDLClear.setEnabled(false) ;
        btnHandStop.setEnabled(false) ;
        ckbBM.setEnabled(false) ;
        ckbDL.setEnabled(false) ;
        ckUpdate.setEnabled(false) ;

        //�������ж��Ƿ�߱�ȡ������

        cat=new ClientAutoStart();
        cat.start() ;
        }
        catch(Exception ea)
        {
        }



    }
    void btnAutoStop_actionPerformed(ActionEvent e) {

        cat.killprogress(true) ;
        while(cat.isAlive() )
        {
        }
        isClientAuto=0;
        btnHandStart.setEnabled(true) ;
        btnAutoStop.setEnabled(false) ;
        btnHandStop.setEnabled(false) ;
        btnAutoStart.setEnabled(true) ;
        btnSave.setEnabled(true) ;
        btnBMSelectAll.setEnabled(true) ;
        btnDLSelectAll.setEnabled(true) ;
        btnBMClear.setEnabled(true) ;
        btnDLClear.setEnabled(true) ;
        ckbBM.setEnabled(true) ;
        ckbDL.setEnabled(true) ;
        ckUpdate.setEnabled(true) ;

        cat=null;

    }
    void btnHandStart_actionPerformed(ActionEvent e) {

    try
    {


        if(!ckbBM.isSelected() &&!ckbDL.isSelected() )
        {
            JOptionPane.showMessageDialog(this,"û��ѡ���������ͣ� ����������","����",JOptionPane.ERROR_MESSAGE);

        }

        if(isParamSave!=1)
        {
            JOptionPane.showMessageDialog(this,"û�����ò�����","����",JOptionPane.ERROR_MESSAGE);
             if(true) return;
        }

        if(ckbBM.isSelected() )
        {
            if(lstBMSelect.getSelectedIndices().length == 0)
            {
                JOptionPane.showMessageDialog(this,"����û��ѡ��һ����·��","����",JOptionPane.ERROR_MESSAGE);
                if(true) return;
            }
            iBM=1;
            iBMCount = lstBMSelect.getSelectedIndices().length;
            //iBMIndex_no����Ϊѡ����·������������
            iBMIndex_no = new int[iBMCount];
            sBMIndex_name = new String[iBMCount];
            String sBMIndex_no = "";
            for(int i=0; i<iBMCount; i++)
            {
                sBMIndex_no = "" + lstBMSelect.getSelectedValues()[i];
                StringTokenizer str = new StringTokenizer(sBMIndex_no,"|");
                sBMIndex_no = str.nextToken().trim();
                sBMIndex_name[i] = sBMIndex_no;
                iBMIndex_no[i] = Integer.parseInt(str.nextToken().trim());
            }
        }
        else
        {
            iBMCount=0;
        }
        if(ckbDL.isSelected() )
        {
            if(lstDLSelect.getSelectedIndices().length == 0)
            {
                JOptionPane.showMessageDialog(this,"����û��ѡ��һ����·��","����",JOptionPane.ERROR_MESSAGE);
                if(true) return;
            }

            iDL=1;
            iDLCount = lstDLSelect.getSelectedIndices().length;
            //iBMIndex_no����Ϊѡ����·������������
            iDLIndex_no = new int[iDLCount];
            sDLIndex_name = new String[iDLCount];
            String sDLIndex_no = "";
            for(int i=0; i<iDLCount; i++)
            {
                sDLIndex_no = "" + lstDLSelect.getSelectedValues()[i];
                StringTokenizer str = new StringTokenizer(sDLIndex_no,"|");
                sDLIndex_no = str.nextToken().trim();
                sDLIndex_name[i] = sDLIndex_no;
                iDLIndex_no[i] = Integer.parseInt(str.nextToken().trim());
            }
        }
        else
        {
            iDLCount=0;
        }

        if(ckUpdate.isSelected() )
        {
            iUpdate=1;
        }
        else
        {
            iUpdate=0;
        }
        isClientAuto=2;
        btnSave.setEnabled(false) ;
        btnBMSelectAll.setEnabled(false) ;
        btnDLSelectAll.setEnabled(false) ;
        btnAutoStart.setEnabled(false) ;
        btnHandStart.setEnabled(false) ;
        btnAutoStop.setEnabled(false) ;
        btnBMClear.setEnabled(false) ;
        btnBMClear.setEnabled(false) ;
        btnHandStop.setEnabled(true) ;
        ckbBM.setEnabled(false) ;
        ckbDL.setEnabled(false) ;
        ckUpdate.setEnabled(false) ;

        //�������ж��Ƿ�߱�ȡ������
        StartGetData();
        }
        catch(Exception dh)
        {

        }

    }

    void btnHandStop_actionPerformed(ActionEvent e) {
        isClientAuto=0;
        btnHandStart.setEnabled(true) ;
        btnAutoStop.setEnabled(false) ;
        btnHandStop.setEnabled(false) ;
        btnAutoStart.setEnabled(true) ;
        btnSave.setEnabled(true) ;
        btnBMSelectAll.setEnabled(true) ;
        btnDLSelectAll.setEnabled(true) ;
        btnBMClear.setEnabled(true) ;
        btnDLClear.setEnabled(true) ;
        ckbBM.setEnabled(true) ;
        ckbDL.setEnabled(true) ;
        ckUpdate.setEnabled(true) ;

    }

    void btnBMSelectAll_actionPerformed(ActionEvent e) {
        //iComponents����ΪҪ��ȫ��ѡ����list����������100����Ŀ����iComponentsΪ0-99�����顣
        int iLength = vBMList.size();
        int[] iComponents = new int[iLength];
        //��iComponents���鸳ֵ
        for(int i=0; i<iLength; i++)
        {
            iComponents[i] = i;
        }
        lstBMSelect.setSelectedIndices(iComponents);
        //����ȫѡ
    }

    void btnAutoSend_actionPerformed(ActionEvent e) {
        isServerAuto=1;
        btnAutoSend.setEnabled(false) ;
        btnAutoSendStop.setEnabled(true) ;
        btnSClear.setEnabled(false) ;
        sat=new ServerAutoStart();
        sat.start() ;





    }

    void btnAutoSendStop_actionPerformed(ActionEvent e) {


       sat.killServer(true) ;
        while(sat.isAlive() )
        {
        }
        isServerAuto=0;
        btnAutoSend.setEnabled(true) ;
        btnAutoSendStop.setEnabled(false) ;
        btnSClear.setEnabled(true) ;

    }

      //������·��������ķ���
      public void a_associate() throws Exception
      {
           if(sktConnect!=null)
           {
               //bCrcΪУ��λ
               byte bCrc = 0;
               ops_Client=sktConnect.getOutputStream();
               dops_Client=new DataOutputStream(ops_Client);
               byte[] bSend = {1,0,0,0,17,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,bCrc};
               //�ѿͻ���ϵͳ�����뵽���ʹ�����
               if(sHostName.length() >16)
                   sHostName=sHostName.substring(0,16);
               byte[] bName=sHostName.getBytes();
               for(int i=0;i<(bName.length);i++)
               {
                    bSend[i+6]=bName[i];
               }
               //ȷ��У�����ֵ
               int iLength=bSend.length;
               byte bTmp=0;
               for(int i=0;i<iLength-1;i++)
               {
                    bTmp=(byte)(bSend[i]+bTmp);
               }
               bSend[iLength-1]=bTmp;
               //����ͨѶԴ��
               dops_Client.write(bSend);
               txtarExplain.append("���ͽ�����·�������\n");
               for(int i=0;i<bSend.length ;i++)
               {
                    txtarCode.append(bSend[i]+" ");
               }
               txtarCode.append("*\n");
           }
       }

        //�������������
       public void a_poll(String sStatus,String sType,int iLineNo,String sYear_start,String sMonth_start,
                String sDay_start,String sHour_start,String sMinute_start,String sYear_end,String sMonth_end,
                String sDay_end,String sHour_end,String sMinute_end,String sDis) throws IOException
       {
            if(sktConnect!=null)
            {
                byte bFrameNo=(byte)iFrameNo;
                byte bCrc = 0;
                byte bLow = (byte)(iLineNo % 256);
                byte bHigh = (byte)((iLineNo-iLineNo % 256)/256);
                ops_Client=sktConnect.getOutputStream();
                dops_Client=new DataOutputStream(ops_Client);
              //
                byte[] bSend={CommFunc.get_byte("14"),bFrameNo,CommFunc.get_byte(sStatus),0,CommFunc.get_byte("11"),0,CommFunc.get_byte(sType),
                                bLow,bHigh,CommFunc.get_byte(sYear_start.substring(0,2)),
                                CommFunc.get_byte(sYear_start.substring(2,4)),CommFunc.get_byte(sMonth_start),
                                CommFunc.get_byte(sDay_start),CommFunc.get_byte(sHour_start),CommFunc.get_byte(sMinute_start),
                                CommFunc.get_byte(sYear_end.substring(0,2)),CommFunc.get_byte(sYear_end.substring(2,4)),
                                CommFunc.get_byte(sMonth_end),CommFunc.get_byte(sDay_end),CommFunc.get_byte(sHour_end),
                                CommFunc.get_byte(sMinute_end),Byte.parseByte(sDis),bCrc};

                byte bTmp=0;
                for(int i=0;i<22;i++)
                {
                    bTmp=(byte)(bSend[i]+bTmp);
                }
                bSend[22] = bTmp;
                dops_Client.write(bSend);
                txtarExplain.append("�����������ݰ���\n");
                for(int i=0;i<23;i++)
                {
                    txtarCode.append(bSend[i]+" ");

                }
                txtarCode.append("*\n");
            }
       }


      //���Ͳ��Ӧ�����ͬ����
      public void a_release_ack() throws Exception
       {
            if(sktConnect!=null)
            {
                ops_Client = sktConnect.getOutputStream();
                dops_Client = new DataOutputStream(ops_Client);
                byte[] bSend = {5,0,0,0,1,0,6};
                dops_Client.write(bSend);
                txtarExplain.append("���Ͳ��Ӧ���(ͬ��������\n");
                for(int i=0;i<7;i++)
                {
                     txtarCode.append(bSend[i]+" ");
                }
                txtarCode.append("*\n");
            }
       }

        //���Ͳ��ʧ��Ӧ���
      public void a_release_nak() throws Exception
      {
            if(sktConnect!=null)
            {
                ops_Client = sktConnect.getOutputStream();
                dops_Client = new DataOutputStream(ops_Client);
                byte[] bSend = {6,0,0,1,1,0,8};
                dops_Client.write(bSend);
                txtarExplain.append("�Ѿ����Ͳ��Ӧ���(���ʧ�ܣ���\n");
                for(int i=0;i<7;i++)
                {
                     txtarCode.append(bSend[i]+" ");
                }
                txtarCode.append("*\n");
            }
       }


    //��������Ӧ��������ճɹ�
    public void a_send_ack() throws Exception
    {
        if(sktConnect!=null)
        {
            byte bFrame_No=(byte)iFrameNo;
            ops_Client = sktConnect.getOutputStream();
            dops_Client=new DataOutputStream(ops_Client);
            byte[] bSend = {24,bFrame_No,0,0,1,0,(byte)(25+bFrame_No)};
            dops_Client.write(bSend);
            txtarExplain.append("�Ѿ���������Ӧ������ɹ�����\n");
            for(int i=0;i<7;i++)
            {
                txtarCode.append(bSend[i]+" ");
            }
            txtarCode.append("*\n");
        }
    }

    //��������Ӧ���������ʧ��
    public void a_send_nak() throws Exception
    {

        if(sktConnect!=null)
        {

            byte bFrame_No=(byte)iFrameNo;
            ops_Client = sktConnect.getOutputStream();
            dops_Client = new DataOutputStream(ops_Client);
            byte[] bSend = {25,bFrame_No,0,0,1,0,(byte)(26+bFrame_No)};
            dops_Client.write(bSend);
            txtarExplain.append("�Ѿ���������Ӧ�����ʧ�ܣ���\n");
            for(int i=0;i<7;i++)
            {
                 txtarCode.append(bSend[i]+" ");
            }
            txtarCode.append("*\n");
        }
    }

     //���շ��������ص����������byte[],�����һλ����-1�����ʾУ��ͳ�����
    public byte[] Receive_Client() throws Exception
    {

        byte[]  bTemp={0,0,0,0,0,0,0};
        if(sktConnect!=null)
        {

            //iNumberΪ�յ����ֽ����鳤�ȣ�bResultΪУ������bSum���ڼ���У���
            int iNumber=0;
            byte bResult=0;

            //��ȡ������
            ips_Client = sktConnect.getInputStream();
            dips_Client = new DataInputStream(ips_Client);

            //���������bReceiveΪ�յ������飬bReturnΪ���ص����飬���һλ��У��λ
            byte[] bGet = new byte[2000];
            iNumber = dips_Client.read(bGet);
            if(iNumber>0)
            {
                byte[] bReturn = new byte[iNumber+1];

                //��ֵ��bReturn[];
                for(int i=0;i<iNumber;i++)
                {
                    bReturn[i]=bGet[i];
                    txtarCode.append(bGet[i]+" ");
                }
                txtarCode.append("*\n");

                //�ҳ����һλ��ֵ��Ϊ-1���ʾУ��ͳ���
                bReturn[iNumber]=1;
                for(int i=0;i<iNumber-1;i++)
                {
                    bResult=(byte)(bReturn[i]+bResult);
                }
                if(bResult!=bReturn[iNumber-1])
                {
                    bReturn[iNumber]=-1;
                    txtarExplain.append("У��ͳ�����\n");

                }
                else
                {
                    txtarExplain.append("�������ݳɹ�.\n");
                }
                return bReturn;
            }
            else
            {
                return bTemp;
            }
        }
        else
        {
            return bTemp;
        }
    }

    public boolean SaveToDB(byte[] SbReceive,String sLineName) throws Exception
    {
        ResultSet rs1=null;
        ResultSet rs2=null;
        ResultSet rs3=null;
        String sMpid = null;
        String sSql="";
        boolean isSave=false;
        String sBegin="";
         //�ҳ����ݰ��еĲ���������������ʱ��
        String sYear = CommFunc.get_H(SbReceive[15])+CommFunc.get_H(SbReceive[16]);
        String sMonth = CommFunc.get_H(SbReceive[17]);
        String sDay = CommFunc.get_H(SbReceive[18]);
        String sHour = CommFunc.get_H(SbReceive[19]);
        String sMinute = CommFunc.get_H(SbReceive[20]);
        String sEa_type = Byte.toString(SbReceive[6]);
        //����ʱ��
        String sEnd = sYear + "-" + sMonth + "-" + sDay + " " +sHour + ":" + sMinute + ":" + "00";
        long lIndex = CommFunc.ByteConvert(SbReceive[7]) + CommFunc.ByteConvert(SbReceive[8])*256;
        long lTotal = CommFunc.ByteConvert(SbReceive[22]) + CommFunc.ByteConvert(SbReceive[23])*256;
        //��ʼʱ��
        String sYear_tmp = CommFunc.get_H(SbReceive[9])+CommFunc.get_H(SbReceive[10]);
        String sMonth_tmp = CommFunc.get_H(SbReceive[11]);
        String sDay_tmp = CommFunc.get_H(SbReceive[12]);
        String sHour_tmp = CommFunc.get_H(SbReceive[13]);
        String sMinute_tmp = CommFunc.get_H(SbReceive[14]);
        FileOutputStream fOut=null;
        sBegin = sYear_tmp + "-" + sMonth_tmp + "-" + sDay_tmp + " " +sHour_tmp + ":" + sMinute_tmp + ":" + "00";
        String sDate = null;
        String sTitle = null;
        String sSqlError="";
        String sErrorDate="";
        Date dErrorDate=null;
        String sUpdateSQL="";
        long lMaxId=0;

        if(iDataCount==0)
        {
            sDateFrom=sBegin;
        }
        sDateTo=sEnd;
        if(lTotal!=0)
        {
            dErrorDate=new java.util.Date();
            sErrorDate=CommFunc.getDateTimeString(dErrorDate.toString() ) ;
           //������д���ļ���ȥ
            String sStartGetData=sErrorDate.substring(0,4)+"��"+sErrorDate.substring(5,7) + "��"+sErrorDate.substring(8,10)
                                +"��" ;
            String sDir="..\\"+sStartGetData;//���û�и�Ŀ¼���򴴽���
            String sDel = null;
            File fileOut=new File(sDir);

            if(!fileOut.isDirectory())
                fileOut.mkdir();
            //�����ļ�����������ļ��򴴽�֮��true�������Ա�д����
            if(sEa_type.equals("1"))
            {
                fOut=new FileOutputStream(sDir+"\\"+sMonth+sDay+sLineName+"����ֵ"+".pmd",true);
            }
            else if(sEa_type.equals("2"))
            {
                fOut=new FileOutputStream(sDir+"\\"+sMonth+sDay+sLineName+"����ֵ"+".pmd",true);
            }
            byte[] bTest="ʱ��ƫ��\tֵ\t\r\n".getBytes();
            fOut.write(bTest);//׷�ӵ��ļ���
            for(int i=0;i<lTotal;i++)
            {
                long iDelta = CommFunc.ByteConvert(SbReceive[24+i*6]) + CommFunc.ByteConvert(SbReceive[25+i*6])*256;
                double dValue = CommFunc.ByteConvert(SbReceive[26+i*6]) + CommFunc.ByteConvert(SbReceive[27+i*6])*256
                              + CommFunc.ByteConvert(SbReceive[28+i*6])*256*256
                              + CommFunc.ByteConvert(SbReceive[29+i*6])*256*256*256;
                if(dValue>999999999)
                    dValue=-10000;
                if(sEa_type.equals("2"))//����
                {
                    sDate = CommFunc.DateAdd("HH",Integer.parseInt(Long.toString(iDelta))-1,sBegin);
                }
                else if(sEa_type.equals("1"))//����
                {
                    sDate = CommFunc.DateAdd("HH",Integer.parseInt(Long.toString(iDelta)),sBegin);
                    iDataCount=iDataCount+1;
                }
                byte[] bWrite = ("" + sDate + "\t" + dValue/1000 +"\r\n").getBytes();
                fOut.write(bWrite);
                //�������ݿ�
                if(sEa_type.equals("2"))
                {
                    sDel = "select * from puao_e_hour_data where puao_id = (select distinct point_des from point_index where mis_no = " + lIndex
                         + ") and pueh_dt = to_date('" + sDate + "','yyyy-mm-dd hh24:mi:ss')";
                    sUpdateSQL="delete puao_e_hour_data where puao_id = (select distinct point_des from point_index where mis_no = " + lIndex
                         + ") and pueh_dt = to_date('" + sDate + "','yyyy-mm-dd hh24:mi:ss')";
                }
                else if(sEa_type.equals("1"))
                {
                    sDel = "select * from wd_e where mp_id = (select distinct point_des from point_index where mis_no = " + lIndex
                         + ") and we_dt = to_date('" + sDate + "','yyyy-mm-dd hh24:mi:ss')";
                    sUpdateSQL="delete wd_e where mp_id = (select distinct point_des from point_index where mis_no = " + lIndex
                         + ") and we_dt = to_date('" + sDate + "','yyyy-mm-dd hh24:mi:ss')";
                }
                if(sDel!=null||sDel.compareTo("")!=0)
                {
                    rs1=stmt_Client.executeQuery(sDel) ;
                    if(!rs1.next() )
                    {
                        rs2=stmt_Client.executeQuery("select distinct point_des from point_index where mis_no = " + lIndex) ;
                        if(rs2.next() )
                        {
                            sMpid=rs2.getString("point_des");
                            if(sEa_type.equals("2"))
                            {
                                sSql = "insert into puao_e_hour_data(puao_id,pueh_dt,pueh_e1,pueh_attr) values('"
                                        + sMpid + "',to_date('" + sDate + "','yyyy-mm-dd hh24:mi:ss')," + dValue/1000 + ",'1008')";
                            }
                            else
                            {
                                sSql = "insert into wd_e(mp_id,we_dt,we_pp,we_type,we_attr) values('"
                                        + sMpid + "',to_date('" + sDate + "','yyyy-mm-dd hh24:mi:ss')," + dValue/1000 + ",'50','104')";
                            }
                            if(dValue==-10000)//д�뱨���¼�
                            {
                                rs3=stmt_Client.executeQuery("select a_sn_seq.nextval as maxid from dual") ;
                                if(rs3.next())
                                   lMaxId=rs3.getLong("maxid");
                                int alid=701;
                                int apass=0;
                                String sdetail="���о�CASTϵͳ���������쳣��";
                                sSqlError="insert into alarm_events (a_sn,al_id,dcp_name,puao_id,a_finddt,a_detial,a_pass) values("
                                            +lMaxId+","+alid+",'"+sLineName+"',"+sMpid+",to_date('" + sErrorDate + "','yyyy-mm-dd hh24:mi:ss'),'"
                                            +sdetail+"',"+apass+")";
                                stmt_Client.executeUpdate(sSqlError) ;
                            }
                            if(sSql!=null||sSql.compareTo("")!=0)
                            {
                                stmt_Client.executeUpdate(sSql);
                            }
                        }

                    }
                    else
                    {
                        if(iUpdate==1)
                        {

                            rs2=stmt_Client.executeQuery("select distinct point_des from point_index where mis_no = " + lIndex) ;
                            if(rs2.next() )
                            {
                                sMpid=rs2.getString("point_des");
                                if(sEa_type.equals("2"))
                                {
                                    sSql = "insert into puao_e_hour_data(puao_id,pueh_dt,pueh_e1,pueh_attr) values('"
                                            + sMpid + "',to_date('" + sDate + "','yyyy-mm-dd hh24:mi:ss')," + dValue/1000 + ",'1008')";
                                }
                                else
                                {
                                    sSql = "insert into wd_e(mp_id,we_dt,we_pp,we_type,we_attr) values('"
                                            + sMpid + "',to_date('" + sDate + "','yyyy-mm-dd hh24:mi:ss')," + dValue/1000 + ",'50','104')";
                                }
                                if(dValue==-10000)//д�뱨���¼�
                                {
                                    rs3=stmt_Client.executeQuery("select a_sn_seq.nextval as maxid from dual") ;
                                    if(rs3.next())
                                        lMaxId=rs3.getLong("maxid");
                                    int alid=701;
                                    int apass=0;
                                    String sdetail="���о�CASTϵͳ���������쳣��";
                                    sSqlError="insert into alarm_events (a_sn,al_id,dcp_name,puao_id,a_finddt,a_detial,a_pass) values("
                                                +lMaxId+","+alid+",'"+sLineName+"',"+sMpid+",to_date('" + sErrorDate + "','yyyy-mm-dd hh24:mi:ss'),'"
                                                +sdetail+"',"+apass+")";

                                    stmt_Client.executeUpdate(sSqlError) ;
                                }
                                if(sSql!=null||sSql.compareTo("")!=0)
                                {
                                    stmt_Client.executeUpdate(sUpdateSQL);
                                    stmt_Client.executeUpdate(sSql);
                                }
                            }

                        }
                    }
                }
            }
            isSave=true;
            if(rs1!=null)
                rs1.close() ;
            if(rs2!=null)
                rs2.close() ;
            if(rs3!=null)
               rs3.close() ;
            fOut.close() ;
        }
        else
        {
            isSave=true;
        }
        return isSave;

    }


    public void SaveToTask(String sPuaoid) throws Exception
    {
        String sTaskSQL="";
        String sDelSQL="";
        String sLevelSQL="";
        String sInsertSQL="";
        String spctdata="1";
        String spctstep="60";
        String spctcreatedt="1999-01-01 00:00:00";
        String spctstartdt="";
        String spctlasttime="";

        String spctlevel="";
        String spctattr="0";
        ResultSet rs1=null;
        ResultSet rs2=null;
        Date date;
        try
        {
            date = new java.util.Date();
            spctcreatedt = CommFunc.getDateTimeString(date.toString());
        }
        catch(Exception ed)
        {
            throw new Exception("date error in task!");
        }
        sTaskSQL="select * from puao_calc_task where puao_id=" + sPuaoid+" and pct_data= " +
                spctdata +  " and pct_step=" +spctstep +" and pct_create_dt=to_date('"+
                spctcreatedt +"','yyyy-mm-dd hh24:mi:ss')";
        sLevelSQL="select puao_level from pu_analysis_object where puao_id="+sPuaoid;
        sDelSQL="delete puao_calc_task where puao_id=" + sPuaoid+" and pct_data=" +
                spctdata + " and pct_step=" +spctstep +" and pct_create_dt=to_date('"+
                spctcreatedt +"','yyyy-mm-dd hh24:mi:ss')";


        try
        {
            rs2=stmt_Client.executeQuery(sLevelSQL) ;
            rs2.next() ;
            spctlevel=rs2.getString("puao_level") ;
            rs1=stmt_Client.executeQuery(sTaskSQL) ;
            sInsertSQL="insert into puao_calc_task(puao_id,pct_data,pct_step,pct_create_dt,pct_from_dt,pct_to_dt,pct_level,pct_attr) values("
                    +sPuaoid+","+spctdata+","+spctstep+",to_date('"+spctcreatedt+"','yyyy-mm-dd hh24:mi:ss')"+",to_date('"+sDateFrom+"','yyyy-mm-dd hh24:mi:ss')"
                    +",to_date('"+sDateTo+"','yyyy-mm-dd hh24:mi:ss'),"+spctlevel+","+spctattr+")";
            if(rs1.next() )
            {

                stmt_Client.executeUpdate(sDelSQL) ;
                stmt_Client.executeUpdate(sInsertSQL) ;

            }
            else
            {
                stmt_Client.executeUpdate(sInsertSQL) ;
            }
            if(rs1!=null)
                rs1=null;
            if(rs2!=null)
                rs2=null;
        }
        catch(Exception etask)
        {
            if(rs1!=null)
                rs1=null;
            if(rs2!=null)
                rs2=null;
            throw new Exception("error when insert into task!");
        }


    }

    public void Recursion(byte[] RbReceive,int q,int iCountTemp) throws Exception
    {

        if(RbReceive[2]==0)//��·i�޺�����
        {
            iFrameNo=CommFunc.ByteToInt(RbReceive[1]) ;
            if(SaveToDB(RbReceive,sTotalIndex_name[q]))
            {
                isCSuccess=true;
            }
            else
            {
                isCSuccess=false;
            }
            //int isNak=0;
            for(int m=0;m<2;m++)
            {
                a_send_ack();
                RbReceive=Receive_Client();
                int iSize=RbReceive.length ;
                if(iSize!=0&&RbReceive[iSize-1]!=-1&&RbReceive[0]==4)
                {
              //      isNak=0;
                    break;
                }
                else if(iSize!=0&&RbReceive[iSize-1]!=-1&&RbReceive[0]==23&&RbReceive[2]==-128)
                {
                //    isNak=0;
                    continue;
                }
                else// if(iSize==0||RbReceive[iSize-1]==-1)
                {
                  //  isNak=1;
                    if(m==1)
                    {
                        isCSuccess=false;
                    }
                    continue;
                }
            }
        }
        else if(RbReceive[2]==1)//�к�����*/
        {
            iFrameNo=CommFunc.ByteToInt(RbReceive[1]) ;
            if(SaveToDB(RbReceive,sTotalIndex_name[q]))
            {
                isCSuccess=true;
            }
            else
            {
                isCSuccess=false;
            }
            for(int m=0;m<2;m++)
            {
                a_send_ack();
                RbReceive=Receive_Client();
                int iSize=RbReceive.length ;
                if(iSize!=0&&RbReceive[iSize-1]!=-1&&RbReceive[0]==23&&(RbReceive[2]==0||RbReceive[2]==1))
                {
                        Recursion(RbReceive,q,iCountTemp);
                        break;
                }
                else if(iSize!=0&&RbReceive[iSize-1]!=-1&&RbReceive[0]==23&&(RbReceive[2]==-127&&RbReceive[2]==-128))
                {
                    continue;
                }
                else// if(iSize==0||RbReceive[iSize-1]==-1)
                {
                    if(m==1)
                    {
                        isCSuccess=false;
                    }
                    continue;
                }
            }
        }
        else
        {
            isCSuccess=false;
        }
    }

    //����������·���ӣ��������ݣ��˿���·����
    public void StartGetData()
    {
        String sKs_nf="";//��ʼ�꣬�ֲ�����
        String sKs_yf="";//��ʼ�£��ֲ�����
        String sKs_ts="";//��ʼ�죬�ֲ�����
        String sKs_xs="";//��ʼʱ���ֲ�����
        String sKs_fz="";//��ʼ�֣��ֲ�����
        String sJs_nf="";//�����꣬�ֲ�����
        String sJs_yf="";//�����£��ֲ�����
        String sJs_ts="";//�����죬�ֲ�����
        String sJs_xs="";//����ʱ���ֲ�����
        String sJs_fz="";//�����֣��ֲ�����
        String sTime="";//ʱ�������ֲ�����
        String sStartWorkDate="";
        Date date = null;
        String sSGDTemp="";
        String sMPuaoid="";
        //��¼��·����״������
        error_name = new Vector();
        right_name = new Vector();
        byte[] bReceive={0,0,0,0,0,0};
        txtarCode.setText("") ;
        txtarExplain.setText("") ;
        ResultSet rsPuaoid=null;
        try
        {
            date = new java.util.Date();
            sStartWorkDate = CommFunc.getDateTimeString(date.toString());
            txtarExplain.append("�������ݿ�ʼʱ�䣺"+sStartWorkDate+".\n") ;
        }
        catch(Exception eDate)
        {
            if(true) return;
        }
        try
        {
            //�����������ݿ�����
            stmt_Client=con.createStatement() ;
        }
        catch(Exception eDB)
        {
            txtarExplain.append("�뱾����������ʧ�ܣ�\n") ;
        }
        int isClientAction=0;//�ͻ�����Ϊ��־��1Ϊ������·��2Ϊ�������ݣ�3Ϊ�Ͽ���·
        iTotalCount=iBMCount+iDLCount;
        sTotalIndex_name=new String[iTotalCount];
        iTotalIndex_no=new int[iTotalCount];
        int iTemp=0;
        for(int i=0;i<iTotalCount;i++)
        {

            if(i>=iBMCount&&iDLCount>0)
            {
                sTotalIndex_name[i]=sDLIndex_name[iTemp];
                iTotalIndex_no[i]=iDLIndex_no[iTemp];
                iTemp+=1;
            }
            else
            {
                sTotalIndex_name[i]=sBMIndex_name[i];
                iTotalIndex_no[i]=iBMIndex_no[i];
            }
        }
        for(int i=0;i<iTotalCount;i++)
        {
            int isRelink=0;
            iFrameNo=0;
            sType="1";
            iDataCount=0;
            if(sktConnect==null)
            {
                try
                {
                    sktConnect=new Socket(sSendIP,12099);
                    if(sktConnect!=null)
                    {
                        txtarExplain.append("�Ѿ����������"+sSendIP+"�ڶ˿�12099��������.\n") ;
                        isRelink=1;
                        isClientAction=0;
                    }
                    else
                    {
                        txtarExplain.append("���������"+sSendIP+"�ڶ˿�12099��������ʧ�ܣ�\n") ;
                    }
                }
                catch(Exception eIP)
                {
                    txtarExplain.append("���������"+sSendIP+"�ڶ˿�6001��������ʧ�ܣ�\n") ;
                }
            }
            if(sktConnect!=null)
            {
                try
                {
                    if(isRelink==1)
                    {
                        for(int m=0;m<2;i++)
                        {
                            a_associate();
                            bReceive=Receive_Client();
                            int iSize=bReceive.length ;
                            if(bReceive[iSize-1]!=-1&&iSize!=0&&bReceive[0]==2)
                            {
                                txtarExplain.append("�������"+sSendIP+"��·�����ɹ���\n") ;
                                isClientAction=1;
                                break;
                            }

                            else
                            {
                                if(m==1)
                                {
                                    txtarExplain.append("�������"+sSendIP+"������·������������ʧ�ܣ�\n") ;
                                    btnHandStart.setEnabled(true) ;
                                    btnHandStop.setEnabled(false) ;
                                    isClientAuto=0;
                                }
                                continue;
                            }
                        }
                    }
                }
                catch(Exception eLink)
                {
                    txtarExplain.append("�������"+sSendIP+"������·����ʧ�ܣ�\n") ;
                  //  System.out.println(eLink.toString() );
                }
                try
                {
                    if(isClientAction==1)
                    {

                        int in_line=iTotalIndex_no[i];
                        String  sStatus="00";
                        isClientAction=1;
                        isCSuccess=false;
                        if(iDLCount>0)
                            if(i>=iBMCount)
                                sType="2";
                        if(sType.equals("2")&&(isClientAuto==1) )//�Զ���ʽ������
                        {
                            sSGDTemp=CommFunc.DateAdd( "HH",1,sAStartYear + "-" + sAStartMonth + "-" +
                                           sAStartDay + " " +sAStartHour + ":" + sAStartMinute+ ":" + "00") ;
                            sKs_nf=sSGDTemp.substring(0,4) ;
                            sKs_yf=sSGDTemp.substring(5,7) ;
                            sKs_ts=sSGDTemp.substring(8,10) ;
                            sKs_xs=sSGDTemp.substring(11,13) ;
                            sKs_fz=sSGDTemp.substring(14,16) ;
                            sSGDTemp=CommFunc.DateAdd("HH",1,sAEndYear + "-" + sAEndMonth + "-" +
                                           sAEndDay + " " +sAEndHour + ":" + sAEndMinute+ ":" + "00") ;
                            sJs_nf=sSGDTemp.substring(0,4) ;
                            sJs_yf=sSGDTemp.substring(5,7) ;
                            sJs_ts=sSGDTemp.substring(8,10) ;
                            sJs_xs=sSGDTemp.substring(11,13) ;
                            sJs_fz=sSGDTemp.substring(14,16) ;
                            if(sTimeGap==null||sTimeGap.compareTo("")==0)
                                sATimeGap="60";
                            sTime=sTimeGap;

                        }
                        else if(sType.equals("1")&&(isClientAuto==1))//�Զ���ʽ������
                        {
                             sKs_nf=sAStartYear;
                            sKs_yf=sAStartMonth;
                            sKs_ts=sAStartDay;
                            sKs_xs=sAStartHour;
                            sKs_fz=sAStartMinute;
                            sJs_nf=sAEndYear;
                            sJs_yf=sAEndMonth;
                            sJs_ts=sAEndDay;
                            sJs_xs=sAEndHour;
                            sJs_fz=sAEndMinute;
                            if(sTimeGap==null||sTimeGap.compareTo("")==0)
                                sATimeGap="60";
                            sTime=sTimeGap;
                        }
                        else if(sType.equals("2")&&(isClientAuto==2) )//�ֶ���ʽ������
                        {
                            sSGDTemp=CommFunc.DateAdd( "HH",1,sStartYear + "-" + sStartMonth + "-" +
                                           sStartDay + " " +sStartHour + ":" + sStartMinute+ ":" + "00") ;
                            sKs_nf=sSGDTemp.substring(0,4) ;
                            sKs_yf=sSGDTemp.substring(5,7) ;
                            sKs_ts=sSGDTemp.substring(8,10) ;
                            sKs_xs=sSGDTemp.substring(11,13) ;
                            sKs_fz=sSGDTemp.substring(14,16) ;
                            sSGDTemp=CommFunc.DateAdd("HH",1,sEndYear + "-" + sEndMonth + "-" +
                                           sEndDay + " " +sEndHour + ":" + sEndMinute+ ":" + "00") ;
                            sJs_nf=sSGDTemp.substring(0,4) ;
                            sJs_yf=sSGDTemp.substring(5,7) ;
                            sJs_ts=sSGDTemp.substring(8,10) ;
                            sJs_xs=sSGDTemp.substring(11,13) ;
                            sJs_fz=sSGDTemp.substring(14,16) ;
                            if(sTimeGap==null||sTimeGap.compareTo("")==0)
                                sATimeGap="60";
                            sTime=sTimeGap;
                        }
                        else //�ֶ���ʽ������
                        {
                            sKs_nf=sStartYear;
                            sKs_yf=sStartMonth;
                            sKs_ts=sStartDay;
                            sKs_xs=sStartHour;
                            sKs_fz=sStartMinute;
                            sJs_nf=sEndYear;
                            sJs_yf=sEndMonth;
                            sJs_ts=sEndDay;
                            sJs_xs=sEndHour;
                            sJs_fz=sEndMinute;
                            if(sTimeGap==null||sTimeGap.compareTo("")==0)
                                sTimeGap="60";
                            sTime=sTimeGap;
                        }

                        for(int j=0;j<2;j++)//ÿ����ط�2�Σ�ѭ��01
                        {
                            if(j!=0)
                               sStatus="80";//�ٴ������ٻ�
                            a_poll(sStatus,sType,in_line,sKs_nf,sKs_yf,sKs_ts,
                            sKs_xs,sKs_fz,sJs_nf,sJs_yf,sJs_ts,sJs_xs,sJs_fz,sTime);
                            bReceive=Receive_Client();
                            int iSize=bReceive.length ;
                            if(bReceive[iSize-1]!=-1&&iSize!=0&&bReceive[0]==23)
                            {
                                isClientAction=2;
                                break;//����������ȷ,�˳��ط�ѭ��01
                            }
                            else
                            {
                                if(j==1)
                                {
                                    txtarExplain.append("�������"+sSendIP+"��������������ʧ�ܣ�\n") ;
                                    isClientAction=0;
                                }
                                continue;
                            }
                        }//ѭ��01����
                    }//isClientAction=1 if����
                    if(isClientAction==2)
                    {
                        Recursion(bReceive,i,iTotalCount);
                        if(isCSuccess==true)
                        {
                            if(i==iTotalCount-1)
                                isClientAction=3;
                            else
                            {
                                isClientAction=1;
                            }
                            try
                            {
                                if(iDataCount!=0)
                                {
                                    String sTempSQL="select distinct point_des from point_index where mis_no = " + iTotalIndex_no[i];
                                    rsPuaoid=stmt_Client.executeQuery(sTempSQL) ;
                                    if(rsPuaoid.next())
                                    {
                                        sMPuaoid=rsPuaoid.getString("point_des");
                                        //����puao_calc_task ����
                                        SaveToTask(sMPuaoid);
                                    }
                                }
                                if(rsPuaoid!=null)
                                    rsPuaoid=null;
                                right_name.addElement(sTotalIndex_name[i]) ;
                            }
                            catch(Exception ec)
                            {
                                error_name.addElement(sTotalIndex_name[i]) ;
                                if(rsPuaoid!=null)
                                    rsPuaoid=null;
                            }
                        }
                        else
                        {
                            error_name.addElement(sTotalIndex_name[i]) ;
                        }
                    }//isClientAction=2 if����
                }
                catch(Exception eData)
                {
                    error_name.addElement(sTotalIndex_name[i]) ;

                }
                try
                {
                    if(i==iTotalCount-1&&isClientAction==3)//�����·
                    {
                        int isNak=0;
                        for(int n=0;n<3;n++)//�����·ѭ��2
                        {
                            if(isNak==0)
                                a_release_ack();
                            if(isNak==1)
                                a_release_nak();
                            bReceive=Receive_Client();
                            int iSize=bReceive.length ;
                            if(iSize!=0&&bReceive[iSize-1]!=-1&&bReceive[0]==4)
                            {
                               isNak=0;
                               continue;
                            }
                            else if(iSize!=0&&bReceive[iSize-1]==-1)
                            {
                                isNak=1;
                                continue;
                            }
                            else
                            {
                                break;
                            }
                        }//�����·ѭ��2����
                        txtarExplain.append("���ݽ�����ϣ��������"+sSendIP+"�Ͽ���·���ӡ�\n") ;
                    }
                }
                catch(Exception eRelease)
                {
                    txtarExplain.append("���ݽ�����ϣ��������"+sSendIP+"�Ͽ���·���ӡ�\n") ;

                }
            }


        }//��·ѭ������
        try
        {
            //��ʾ�������ݳɹ���·
            if(!right_name.isEmpty() )
            {
                Enumeration enright=right_name.elements() ;
                txtarExplain.append("�������ݳɹ���·��\n") ;
                while(enright.hasMoreElements() )
                {
                    txtarExplain.append(enright.nextElement() +" "+"\n") ;
                }
                right_name.removeAllElements() ;
            }
            //��ʾ��������ʧ����·
            if(!error_name.isEmpty() )
            {
                Enumeration enerror=error_name.elements() ;
                txtarExplain.append("��������ʧ����·��\n") ;
                while(enerror.hasMoreElements() )
                {
                    txtarExplain.append(enerror.nextElement() +" "+"\n") ;
                }
                error_name.removeAllElements() ;
            }
            if(sktConnect!=null)
                sktConnect=null;
            if(stmt_Client!=null)
                stmt_Client=null;
        }
        catch(Exception e2)
        {
            //��ʾ�������ݳɹ���·
            if(!right_name.isEmpty() )
            {
                Enumeration enright=right_name.elements() ;
                txtarExplain.append("�������ݳɹ���·��\n") ;
                while(enright.hasMoreElements() )
                {
                    txtarExplain.append(enright.nextElement() +" "+"\n") ;
                }
                right_name.removeAllElements() ;
            }
             //��ʾ��������ʧ����·
            if(!error_name.isEmpty() )
            {
                Enumeration enerror=error_name.elements() ;
                txtarExplain.append("��������ʧ����·��\n") ;
                while(enerror.hasMoreElements() )
                {
                    txtarExplain.append(enerror.nextElement() +" "+"\n") ;
                }
                error_name.removeAllElements() ;
            }
            if(sktConnect!=null)
                sktConnect=null;
            if(stmt_Client!=null)
                stmt_Client=null;
        }
    }

    void cmbTimeGap_itemStateChanged(ItemEvent e) {
        sTimeGap=cmbTimeGap.getSelectedItem().toString()  ;
    }

    void btnDLSelectAll_actionPerformed(ActionEvent e) {
    //iComponents����ΪҪ��ȫ��ѡ����list����������100����Ŀ����iComponentsΪ0-99�����顣
        int iLength = vDLList.size();
        int[] iComponents = new int[iLength];
        //��iComponents���鸳ֵ
        for(int i=0; i<iLength; i++)
        {
            iComponents[i] = i;
        }
        lstDLSelect.setSelectedIndices(iComponents);
        //����ȫѡ
    }

    void btnBMClear_actionPerformed(ActionEvent e) {
        lstBMSelect.clearSelection() ;
    }

    void btnDLClear_actionPerformed(ActionEvent e) {
         lstDLSelect.clearSelection() ;
    }

    protected void finalize()
    {
        try
        {

            if(ops_Client!=null)
             {
                ops_Client.close() ;
                ops_Client=null;
             }
             if(ips_Client!=null)
             {
                ips_Client.close();
                ips_Client=null;
             }
             if(dops_Client!=null)
             {
                dops_Client.close() ;
                dops_Client=null;
             }
             if(dips_Client!=null)
             {
                dips_Client.close();
                dips_Client=null;
             }

            if(sktConnect!=null)
                sktConnect.close();
            if(stmt_Client!=null)
            {
                stmt_Client.close() ;
                stmt_Client=null;
            }

            if(cat.isAlive() )
            {
                 cat=null;

            }
           if(sat.isAlive() )
            {
               sat=null;
            }

            if(con!=null)
                con.close() ;


        }
        catch(Exception e6)
        {
        }
    }

    class ClientAutoStart extends Thread
    {
       int i,ihaveexist;
       Date date = null;
       String sDate_temp = null;
       String sDate_begin = null;
       String sDate_old = "1900-01-01 00:30:00";
       boolean stopstatus = false;
       boolean alivestatus = true;

       public ClientAutoStart()
       {
       }


       public void killprogress(boolean value)
       {
            stopstatus = value;
       }
       public void run()
       {

            while(!stopstatus)
            {
                i=0;
                try
                {
                    while((!stopstatus)&&(i<=1000))
                    {
                        i++;
                        this.sleep(10);
                    }

                    date = new java.util.Date();
                    sDate_temp = CommFunc.getDateTimeString(date.toString());
                    String scm=sDate_temp.substring(11,16);
                    if(sDate_temp.substring(0,10).equals(sDate_old.substring(0,10)))
                    {
                        continue;
                    }
                    else if(scm.equals(sAutoTime))
                    {
                        sDate_begin = CommFunc.DateAdd("DD",-1,sDate_temp);
                        sAStartYear = sDate_begin.substring(0,4);
                        sAStartMonth = sDate_begin.substring(5,7);
                        sAStartDay = sDate_begin.substring(8,10);
                        sAStartHour = "00";
                        sAStartMinute = "00";
                        //sAStartHour = sDate_begin.substring(11,13);
                        //sAStartMinute = sDate_begin.substring(14,16);
                        sAEndYear = sDate_temp.substring(0,4);
                        sAEndMonth = sDate_temp.substring(5,7);
                        sAEndDay = sDate_temp.substring(8,10);
                        sAEndHour = "00";
                        sAEndMinute ="00";
                        StartGetData();
                        sDate_old = sDate_temp;
                    }
                }
                catch(InterruptedException ex)
                {
                    ex.printStackTrace();
                }
            }
       }
    }


    class ServerAutoStart extends Thread
    {
        private int isTimeOut=0;//��ʱ��־��1Ϊ��ʱ��0Ϊ����
        private int isServerAction=0;//�������Ϊ��־��1Ϊ������·����2Ϊ�������ݣ�3Ϊ�Ͽ���·
        //����socket�׽���
        Socket hostsocket=null;
        ServerSocket serversocket=null;
         //�����壬socket�������������Ҫת��Ϊ�������������
        OutputStream ops_Server;
        InputStream ips_Server;
        DataOutputStream dos_Server;
        BufferedInputStream bis_Server;
        Vector error_nameS=null;
        Vector right_nameS=null;
        byte[] bAskData=new byte[999];//���������������������
        byte[] bReturn={0,0,0,0,0,0};
        java.sql.Statement stmt_Server=null;
        ResultSet rs_Server=null;
        boolean bkill=false;
        String sWorkDate="";
        Date dWorkDate=null;
        public  ServerAutoStart()
        {
        }
        public void killServer(boolean isKill)
        {
            this.bkill=isKill;
        }

        public void run()
        {
            try
            {
                serversocket=new ServerSocket(12099);
                serversocket.setSoTimeout(30000) ;
            }
            catch(Exception esk)
            {
               txtarSExplain.append("ϵͳ����"+esk.toString() +"\n") ;
            }

            while(!bkill)//����ѭ��1
            {
                synchronized (this){

                isServerAction=0;
                try
                {


                    this.sleep(1000);

                    hostsocket=serversocket.accept() ;
                    hostsocket.setSoTimeout(60000);//��ʱ60��
                }
                catch(Exception e)
                {

                }

                if(hostsocket!=null)
                {
                    dWorkDate=new Date();
                    sWorkDate=CommFunc.getDateTimeString(dWorkDate.toString());
                    txtarSExplain.append("�������ݿ�ʼʱ�䣺"+sWorkDate+"\n") ;
                    txtarSCode.append("�������ݿ�ʼʱ�䣺"+sWorkDate+"\n") ;
                    for(int i=0;i<3;i++)//ѭ��01
                    {
                       try
                       {
                            if(i!=0)
                                a_associate_nak();
                            if(i==2)
                            {
                                txtarSExplain.append("������ϣ�\n") ;
                                if(hostsocket!=null)
                                {
                                    hostsocket.close() ;
                                    hostsocket=null;
                                }
                            }
                       }
                       catch(Exception eas)
                       {
                            if(i==2)
                            {
                                txtarSExplain.append("������ϣ�\n") ;

                            }
                       }

                       try
                       {
                            bReturn=Receive_Server();

                            int iSize=bReturn.length ;
                            if(iSize!=0&&bReturn[iSize-1]!=-1&&bReturn[0]==1)
                            {
                                isServerAction=1;
                                break;
                            }
                            else
                            {
                                if(i==2)
                                {
                                    txtarSExplain.append("������ϣ�\n") ;
                                    if(hostsocket!=null)
                                    {
                                        hostsocket.close() ;
                                        hostsocket=null;
                                    }

                                }
                                continue;
                            }
                       }
                       catch(InterruptedIOException e)
                       {
                            if (e.toString().equals("readoutoftime")&&i==2 )
                            {
                                txtarSExplain.append("������ϣ�\n") ;

                             }
                       }
                       catch(Exception ee)
                       {
                            if(i==2)
                            {
                                txtarSExplain.append("������ϣ�\n") ;

                            }
                       }

                    }//ѭ��01����

                    if(isServerAction==1)//isServerAction==1if��������·
                    {
                        for(int i=0;i<3;i++)
                        {
                            try
                            {
                                a_associate_ack();
                                if(i==2)
                                {
                                    txtarSExplain.append("������ϣ�\n") ;
                                    if(hostsocket!=null)
                                    {
                                        hostsocket.close() ;
                                        hostsocket=null;
                                    }
                                }
                            }
                            catch(Exception eas)
                            {
                                if(i==2)
                                {
                                    txtarSExplain.append("������ϣ�\n") ;

                                }
                            }

                            try
                            {
                                 bReturn=Receive_Server();
                                int iSize=bReturn.length ;
                                if(iSize!=0&&bReturn[iSize-1]!=-1&&bReturn[0]==20)
                                {
                                    for(int k=0;k<iSize;k++)
                                    {
                                        bAskData[k]=bReturn[k];
                                    }
                                    isServerAction=2;
                                    break;
                                }
                                else
                                {
                                    if(i==2)
                                    {
                                        txtarSExplain.append("������ϣ�\n") ;
                                        try
                                        {
                                            if(hostsocket!=null)
                                            {
                                                hostsocket.close() ;
                                                hostsocket=null;
                                            }
                                        }
                                        catch(Exception ei2)
                                        {
                                        }
                                    }
                                    continue;
                                }

                            }
                            catch(InterruptedIOException e)
                            {
                                if (e.toString().equals("readoutoftime")&&i==2 )
                                {
                                    txtarSExplain.append("������ϣ�\n") ;
                                }
                            }

                        }
                    }//isServerAction==1if����
                    if(isServerAction==2)//isServerAction==2����������
                    {
                        SRecursion(bReturn);
                    }//isServerAction==2if����
                    try
                    {
                        if(hostsocket!=null)
                        {
                            hostsocket.close() ;
                            hostsocket=null;
                        }

                    }
                    catch(Exception ec)
                    {
                    }


                }
                else
                {
                }
                }
            }//����ѭ��1����
            try
            {
                if(serversocket!=null)
                {
                    serversocket.close() ;
                    serversocket=null;
                }
            }
            catch(Exception el)
            {

            }



        }

        public void SRecursion(byte[] SRbReturn)
        {

            int iSFrameNo=0;//�������
            int iSPCount=0;//�������ݰ���

            String sSValueType = Byte.toString(bAskData[6]);
            long lSLineNo = CommFunc.ByteConvert(bAskData[7]) + CommFunc.ByteConvert(bAskData[8])*256;
            String sSStartYear=CommFunc.get_H(bAskData[9])+CommFunc.get_H(bAskData[10]);
            String sSEndYear=CommFunc.get_H(bAskData[15])+CommFunc.get_H(bAskData[16]);
            String sSStartMonth = CommFunc.get_H(bAskData[11]);
            String sSEndMonth = CommFunc.get_H(bAskData[17]);
            String sSStartDay = CommFunc.get_H(bAskData[12]);
            String sSEndDay = CommFunc.get_H(bAskData[18]);
            String sSStartHour = CommFunc.get_H(bAskData[13]);
            String sSEndHour = CommFunc.get_H(bAskData[19]);
            String sSStartMinute = CommFunc.get_H(bAskData[14]);
            String sSEndMinute = CommFunc.get_H(bAskData[20]);
            String sSStartDate=sSStartYear+"-"+sSStartMonth+"-"+sSStartDay+" "+sSStartHour+":"+sSStartMinute+":00";
            String sSEndDate=sSEndYear+"-"+sSEndMonth+"-"+sSEndDay+" "+sSEndHour+":"+sSEndMinute+":00";
            long[] lSendData=new long[288];
            int[] iTimeGap=new int[288];
            Date dStart=null;
            Date dEnd=null;
            //�����ݿ���ȡ����
          /*  if(lSLineNo==12) lSLineNo=10356;
            if(lSLineNo==14) lSLineNo=10330;
            if(lSLineNo==16) lSLineNo=10331;
            if(lSLineNo==689) lSLineNo=10316;
            if(lSLineNo==691) lSLineNo=10317;
            if(lSLineNo==693) lSLineNo=10318;*/
            int iRecordCount=LoadFromDB(sSStartDate,sSEndDate,lSLineNo,sSValueType);
            if(iRecordCount==-1)
            {
                txtarExplain.append("�������ݿ����ʧ�ܣ��ж����ӣ�\n") ;
                return;
            }
            else
            {
                iSPCount=iRecordCount/288;
                if((iRecordCount%288)!=0)
                    iSPCount+=1;
                if(iSPCount==0)
                    iSPCount=1;
                iSFrameNo=-1;
                //���巢��
                int isExit=0;
                int iTemp=0;
                for(int j=0;j<iSPCount;j++)//���巢��ѭ��(������)
                {
                    String sTempSY="";
                    String sTempSM="";
                    String sTempSD="";
                    String sTempSH="";
                    String sTempSF="";
                    String sTempEY="";
                    String sTempEM="";
                    String sTempED="";
                    String sTempEH="";
                    String sTempEF="";
                    iTemp=0;

                    if(iRecordCount==0)
                    {
                        sTempSY=sSStartYear;
                        sTempSM=sSStartMonth;
                        sTempSD=sSStartDay;
                        sTempSH=sSStartHour;
                        sTempSF=sSStartMinute;
                        sTempEY=sSEndYear;
                        sTempEM=sSEndMonth;
                        sTempED=sSEndDay;
                        sTempEH=sSEndHour;
                        sTempEF=sSEndMinute;
                        iTimeGap[0]=0;
                        lSendData[0]=0;

                    }
                    else
                    {
                        try
                        {
                            while(rs_Server.next()&iTemp<288 )
                            {
                                if(iTemp==0)
                                {
                                    sTempSY=rs_Server.getString("ddate").substring(0,4);
                                    sTempSM=rs_Server.getString("ddate").substring(5,7);
                                    sTempSD=rs_Server.getString("ddate").substring(8,10);
                                    sTempSH=rs_Server.getString("ddate").substring(11,13);
                                    sTempSF=rs_Server.getString("ddate").substring(14,16);
                                    dStart=CommFunc.getdate(rs_Server.getString("ddate")) ;
                                }
                                sTempEY=rs_Server.getString("ddate").substring(0,4);
                                sTempEM=rs_Server.getString("ddate").substring(5,7);
                                sTempED=rs_Server.getString("ddate").substring(8,10);
                                sTempEH=rs_Server.getString("ddate").substring(11,13);
                                sTempEF=rs_Server.getString("ddate").substring(14,16);
                                dEnd=CommFunc.getdate(rs_Server.getString("ddate")) ;
                                iTimeGap[iTemp]=(int)(((dEnd.getTime() - dStart.getTime() )/1000)/(60*60));
                                lSendData[iTemp]=(long)(rs_Server.getFloat("ddata")*1000) ;
                                iTemp+=1;
                            }//288while����
                        }
                        catch(SQLException esql)
                        {
                            txtarSExplain.append("�������ݿ�����쳣��\n") ;

                            break;
                        }

                    }

                    iSFrameNo+=1;
                    String sSStatus="00";
                    for(int m=0;m<3;m++)//�ط�ѭ��02
                    {
                        if(m==0&&(j!=iSPCount-1))
                            sSStatus="01";
                        if(m!=0&&(j!=iSPCount-1))
                            sSStatus="81";
                        if(m==0&&(j==iSPCount-1))
                            sSStatus="00";
                        if(m!=0&&(j==iSPCount-1))
                            sSStatus="80";
                        try
                        {
                            a_send(iSFrameNo,sSStatus,sSValueType,lSLineNo,sTempSY,sTempSM,sTempSD,sTempSH,sTempSF,
                                    sTempEY,sTempEM,sTempED,sTempEH,sTempEF,"60",iTemp,iTimeGap,lSendData);

                            if(m==2)
                            {
                               txtarSExplain.append("������ϣ�\n") ;
                               if(hostsocket!=null)
                               {
                                   hostsocket.close() ;
                                   hostsocket=null;
                                }
                                isExit=1;
                             }
                        }
                        catch(Exception esend)
                        {
                             if(m==2)
                             {
                                txtarSExplain.append("������ϣ�\n") ;
                                isExit=1;

                             }
                        }

                        try
                        {
                            SRbReturn=Receive_Server();
                            int iSize=SRbReturn.length ;
                            if(iSize!=0&&SRbReturn[iSize-1]!=-1&&SRbReturn[0]==24)
                            {
                                break;
                            }
                            else
                            {
                                if(m==2)
                                {
                                    txtarSExplain.append("������ϣ�\n") ;
                                    //�˳����巢��ѭ��
                                    isExit=1;
                                }
                                continue;
                            }
                        }
                        catch(InterruptedIOException e)
                        {
                            if (e.toString().equals("readoutoftime")&&m==2 )
                            {
                                txtarSExplain.append("������ϣ�\n") ;
                                //�˳����巢��ѭ��
                                isExit=1;
                             }
                        }
                        catch(Exception eas)
                        {
                            if(m==2)
                            {
                                txtarSExplain.append("������ϣ�\n") ;
                                isExit=1;
                            }
                        }

                    }//�ط�ѭ��02����
                    if(isExit==1)
                        break;
                    if(j==iSPCount-1)//��·�Ͽ�������
                    {
                        for(int n=0;n<3;n++)
                        {
                            try
                            {
                                a_release();
                                if(n==2)
                                {
                                    txtarSExplain.append("������ϣ�\n") ;
                                    if(hostsocket!=null)
                                    {
                                        hostsocket.close() ;
                                        hostsocket=null;
                                    }
                                    isExit=1;
                                }
                            }
                            catch(Exception e)
                            {
                                if(n==2)
                                {
                                    txtarSExplain.append("������ϣ�\n") ;
                                    isExit=1;
                                }

                            }
                            try
                            {
                                SRbReturn=Receive_Server();
                                int iSize=SRbReturn.length ;
                                if(iSize!=0&&SRbReturn[iSize-1]!=-1&&SRbReturn[0]==20)
                                {

                                    for(int k=0;k<iSize;k++)
                                    {
                                        bAskData[k]=SRbReturn[k];
                                    }
                                    //�ͻ��˼��������ݷ������󣬽���ݹ麯��
                                    SRecursion(SRbReturn);
                                    isExit=1;
                                    break;
                                }
                                else if(iSize!=0&&SRbReturn[iSize-1]!=-1&&SRbReturn[0]==5)
                                {
                                    //�ͻ�ͬ��Ͽ���·
                                    isExit=1;
                                    break;
                                }
                                else
                                {
                                    if(n==2)
                                    {
                                        txtarSExplain.append("������ϣ�\n") ;
                                        isExit=1;
                                        try
                                        {
                                            if(hostsocket!=null)
                                            {
                                                hostsocket.close() ;
                                                hostsocket=null;
                                            }
                                        }
                                        catch(Exception en2)
                                        {
                                        }

                                    }
                                    continue;
                                }
                            }
                            catch(InterruptedIOException eio)
                            {
                                if (eio.toString().equals("readoutoftime")&&n==2 )
                                {
                                    txtarSExplain.append("������ϣ�\n") ;
                                    isExit=1;
                                }
                            }
                            catch(Exception elo)
                            {
                                if(n==2)
                                {
                                    txtarSExplain.append("������ϣ�\n") ;
                                    isExit=1;

                                }
                            }

                        }
                    }
                    if(isExit==1)
                        break;
                }//���巢��ѭ������
            }//ȡ���ݳɹ��жϽ���
            try
            {
                if(rs_Server!=null)
                {
                    rs_Server.close() ;
                    rs_Server=null;
                }
            }
            catch(Exception ee)
            {
            }
        }


         //���������Ӧ������ɹ���
        public void a_associate_ack() throws Exception
        {
            if(hostsocket!=null)
            {
                ops_Server=hostsocket.getOutputStream();
                dos_Server=new DataOutputStream(ops_Server);
                byte bCrc=0;
                byte bTmp=0;
                String sServer_name="������վ�����";
                byte[] bServer_name=sServer_name.getBytes();
                byte[] bSend={2,0,0,0,17,0,-77,-57,-50,-9,-66,-42,0,0,0,0,0,0,0,0,0,0,bCrc};
                for(int i=0;i<bServer_name.length;i++)
                {
                    bSend[i+6]=bServer_name[i];
                }
                for(int i=0;i<22;i++)
                {
                    bCrc=(byte)(bSend[i]+bTmp);
                    bTmp=bCrc;
                }
                bSend[22]=bCrc;
                dos_Server.write(bSend);//�����Ҫ���͵���Ϣ
                txtarSExplain.append("������·Ӧ�������·���ӳɹ�����\n");
                for(int i=0;i<23;i++)
                {
                    txtarSCode.append(bSend[i]+" ");
                }
                txtarSCode.append("*\n");
            }
        }

        //����Ӧ�����ʧ�ܣ�
        public void a_associate_nak() throws Exception
        {

            if(hostsocket!=null)
            {
                ops_Server=hostsocket.getOutputStream();
                dos_Server=new DataOutputStream(ops_Server);
                byte bCrc=0;
                byte bTmp=0;
                String sServer_name="������վ�����";
                byte[] bServer_name=sServer_name.getBytes();
                byte[] bSend={3,0,0,1,17,0,-77,-57,-50,-9,-66,-42,0,0,0,0,0,0,0,0,0,0,bCrc};
                for(int i=0;i<bServer_name.length;i++)
                {
                    bSend[i+6]=bServer_name[i];
                }
                for(int i=0;i<22;i++)
                {
                    bCrc=(byte)(bSend[i]+bTmp);
                    bTmp=bCrc;
                }
                bSend[22]=bCrc;
                dos_Server.write(bSend);//�����Ҫ���͵���Ϣ
                txtarSExplain.append("������·Ӧ���(��·���Ӳ��ɹ�)��\n");
                for(int i=0;i<23;i++)
                {
                    txtarSCode.append(bSend[i]+" ");
                }
                txtarSCode.append("*\n");
            }
        }

        //�ͷ����������
        public void a_release() throws Exception
        {
            if(hostsocket!=null)
            {
                ops_Server=hostsocket.getOutputStream();
                dos_Server=new DataOutputStream(ops_Server);
                byte[] bSend={4,0,0,0,1,0,5};
                dos_Server.write(bSend);
                txtarSExplain.append("������·��·�������\n");
                for(int i=0;i<7;i++)
                {
                    txtarSCode.append(bSend[i]+" ");
                }
                txtarSCode.append("*\n");
            }
        }


         //��ȡ��������İ�,����byte[]����
        public byte[] Receive_Server( ) throws InterruptedIOException
        {
                byte[] bGet=new byte[999];
                byte bResult=0;
                byte[] bTemp={0,0,0,0,0,0};
                int iNumber=0;
                try
                {
                    ips_Server=hostsocket.getInputStream();
                    bis_Server=new BufferedInputStream(ips_Server);
                    iNumber=bis_Server.read(bGet);
                }

                catch(InterruptedIOException ei)
                {

                    throw new InterruptedIOException("readoutoftime");

                }
                catch(IOException eo)
                {
                    return bTemp;
                }

                if(iNumber>0)
                {
                    byte[] bReturn = new byte[iNumber+1];

                    //��ֵ��bReturn[];
                    for(int i=0;i<iNumber;i++)
                    {
                        bReturn[i]=bGet[i];
                        txtarSCode.append(bGet[i]+" ");
                    }

                    txtarSCode.append("*\n");

                    //�ҳ����һλ��ֵ��Ϊ-1���ʾУ��ͳ���
                    bReturn[iNumber]=1;
                    for(int i=0;i<iNumber-1;i++)
                    {
                        bResult=(byte)(bReturn[i]+bResult);
                    }
                    if(bResult!=bReturn[iNumber-1])
                    {
                        bReturn[iNumber]=-1;
                        txtarSExplain.append("У��ͳ�����\n");

                    }
                    else
                    {
                        txtarSExplain.append("�������ݳɹ���\n");
                    }
                    return bReturn;
                }
                else
                {
                    return bTemp;
                }

        }

        //�����ݿ�ȡ����
        public int LoadFromDB(String sStart_Date,String sEnd_Date,long lLine_No,String sData_Type)
        {
            int iLoadCount=-1;
            String sSql="";
            String sSqlCount="";
            ResultSet rsCount=null;

            try
            {
                stmt_Server=con.createStatement() ;

                if(sData_Type.compareTo("1") ==0)
                {
                    sSql="select mp_id as id,to_char(we_dt,'yyyy-mm-dd hh24:mi:ss') as ddate,we_pp as ddata from wd_e where mp_id="+lLine_No+" and we_dt>=to_date('"+
                            sStart_Date+"','yyyy-mm-dd hh24:mi:ss') and we_dt<=to_date('"+sEnd_Date
                            +"','yyyy-mm-dd hh24:mi:ss') order by we_dt";
                    sSqlCount="select count(*) as iCount from wd_e where mp_id="+lLine_No+" and we_dt>=to_date('"+
                            sStart_Date+"','yyyy-mm-dd hh24:mi:ss') and we_dt<=to_date('"+sEnd_Date
                            +"','yyyy-mm-dd hh24:mi:ss')";
                }
                else if(sData_Type.compareTo("2") ==0)
                {
                    sSql="select puao_id as id,to_char(pueh_dt,'yyyy-mm-dd hh24:mi:ss') as ddate,pueh_e1 as ddata from puao_e_hour_data where puao_id="+lLine_No+" and pueh_dt>=to_date('"+
                            sStart_Date+"','yyyy-mm-dd hh24:mi:ss') and pueh_dt<=to_date('"+sEnd_Date
                            +"','yyyy-mm-dd hh24:mi:ss') order by pueh_dt";
                    sSqlCount="select count(*) as iCount from puao_e_hour_data where puao_id="+lLine_No+" and pueh_dt>=to_date('"+
                            sStart_Date+"','yyyy-mm-dd hh24:mi:ss') and pueh_dt<=to_date('"+sEnd_Date
                            +"','yyyy-mm-dd hh24:mi:ss')";

                }
                if(sSqlCount!=null||sSqlCount.compareTo("") !=0)
                {
                    rsCount=stmt_Server.executeQuery(sSqlCount) ;
                    if(rsCount.next() )
                        iLoadCount=rsCount.getInt("iCount") ;
                    else
                        iLoadCount=0;
                    rs_Server=stmt_Server.executeQuery(sSql) ;
                    if(rsCount!=null)
                        rsCount.close() ;
                }
            }
            catch(Exception eLoad)
            {
                return -1;
            }

            return iLoadCount;
        }


        //���ݷ��Ͱ�
        public void a_send(int iSFrame_No,String sS_Status,String sValue_Type,long lLine_No,String sStart_Year,String sStart_Month,
                          String sStart_Day,String sStart_Hour,String sStart_Minute,String sEnd_Year,String sEnd_Month,
                          String sEnd_Day,String sEnd_Hour,String sEnd_Minute,String sTime_Gap,int iValueCount,int [] iTime_Gap,long[] lSend_Data) throws Exception
        {

            if(hostsocket!=null)
            {
                int iDataCount=25+iValueCount*6;
                int iInfoCount=iDataCount-6;
                byte bFrameNo=(byte)iSFrame_No;
                byte bCrc=0;
                byte bLow=(byte)(lLine_No%256);
                byte bHigh=(byte)((lLine_No-lLine_No%256)/256);
                byte bLCount=(byte)(iValueCount%256);
                byte bHCount=(byte)((iValueCount-iValueCount%256)/256);
                byte bILow=(byte)(iInfoCount%256);
                byte bIHigh=(byte)((iInfoCount-iInfoCount%256)/256);
                byte[] bSend=new byte[iDataCount];
                ops_Server=hostsocket.getOutputStream();
                dos_Server=new DataOutputStream(ops_Server);
                bSend[0]=23;
                bSend[1]=bFrameNo;
                bSend[2]=CommFunc.get_byte(sS_Status);
                bSend[3]=0;
                bSend[4]=bILow;
                bSend[5]=bIHigh;
                bSend[6]=CommFunc.get_byte(sValue_Type);
                bSend[7]=bLow;
                bSend[8]=bHigh;
                bSend[9]=CommFunc.get_byte(sStart_Year.substring(0,2) );
                bSend[10]=CommFunc.get_byte(sStart_Year.substring(2,4));
                bSend[11]=CommFunc.get_byte(sStart_Month);
                bSend[12]=CommFunc.get_byte(sStart_Day);
                bSend[13]=CommFunc.get_byte(sStart_Hour);
                bSend[14]=CommFunc.get_byte(sStart_Minute);
                bSend[15]=CommFunc.get_byte(sEnd_Year.substring(0,2) );
                bSend[16]=CommFunc.get_byte(sEnd_Year.substring(2,4));
                bSend[17]=CommFunc.get_byte(sEnd_Month);
                bSend[18]=CommFunc.get_byte(sEnd_Day);
                bSend[19]=CommFunc.get_byte(sEnd_Hour);
                bSend[20]=CommFunc.get_byte(sEnd_Minute);
                bSend[21]=Byte.parseByte(sTime_Gap) ;

                if(iValueCount==0)
                {
                    bSend[22]=0;
                    bSend[23]=0;
                }
                else
                {
                    byte bData1;
                    byte bData2;
                    byte bData3;
                    byte bData4;
                    bSend[22]=bLCount;
                    bSend[23]=bHCount;
                    for(int i=0;i<iValueCount;i++)
                    {
                        bData1=(byte)(lSend_Data[i]%256);
                        bData2=(byte)(lSend_Data[i]/256%256);
                        bData3=(byte)(lSend_Data[i]/256/256%256);
                        bData4=(byte)(lSend_Data[i]/256/256/256%256);
                        bSend[24+i*6]=(byte)(iTime_Gap[i]%256);
                        bSend[25+i*6]=(byte)((iTime_Gap[i]-iTime_Gap[i]%256)/256);
                        bSend[26+i*6]=bData1;
                        bSend[27+i*6]=bData2;
                        bSend[28+i*6]=bData3;
                        bSend[29+i*6]=bData4;
                    }
                }

                int iSize=bSend.length ;
                for(int i=0;i<iSize-1 ;i++)
                {
                    bCrc=(byte)(bSend[i]+bCrc);
                }
                bSend[iSize-1]=bCrc;
                dos_Server.write(bSend);
                txtarSExplain.append("�Ѿ��������ݰ���\n");

                for(int i=0;i<bSend.length ;i++)
                {
                    txtarSCode.append(bSend[i]+" ");
                }
                txtarSCode.append("*\n");
            }
        }


        protected void finalize()
        {
             try
             {
                 if(ops_Server!=null)
                 {
                    ops_Server.close() ;
                    ops_Server=null;
                 }
                 if(ips_Server!=null)
                 {
                    ips_Server.close();
                    ips_Server=null;
                 }
                 if(dos_Server!=null)
                 {
                    dos_Server.close() ;
                    dos_Server=null;
                 }
                 if(bis_Server!=null)
                 {
                    bis_Server.close();
                    bis_Server=null;
                 }
                 if(serversocket!=null)
                    serversocket.close() ;
                 if(hostsocket!=null)
                    hostsocket.close() ;
                 if(stmt_Server!=null)
                 {
                    stmt_Server.close() ;
                    stmt_Server=null;
                 }
             }
             catch(Exception ee)
             {
             }

        }

    }



    void btnSClear_actionPerformed(ActionEvent e) {
        if(!sat.isAlive() )
        {
          txtarSExplain.setText("") ;
          txtarSCode.setText("") ;

        }

    }



}
